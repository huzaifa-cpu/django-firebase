// ignore_for_file: unused_import

import 'package:flutter/material.dart';

class ChatDummyModel {
  final String name;
  final String profilePic;
  final String lastMessage;
  final int unreadMessages;
  final String time;

  ChatDummyModel({
    required this.name,
    required this.profilePic,
    required this.lastMessage,
    required this.unreadMessages,
    required this.time,
  });
}

final List<ChatDummyModel> chats = [
  ChatDummyModel(
    name: 'Anna Bella',
    profilePic: 'images/profile_1.png',
    lastMessage: 'Great! Thank you so much',
    unreadMessages: 4,
    time: '12:30 PM',
  ),
  ChatDummyModel(
    name: 'Mark Stegan',
    profilePic: 'images/profile_2.png',
    lastMessage: 'Great! Thank you so much',
    unreadMessages: 5,
    time: '12:30 PM',
  ),
  ChatDummyModel(
    name: 'Zehan Zou',
    profilePic: 'images/profile_3.png',
    lastMessage: 'Great! Thank you so much',
    unreadMessages: 1,
    time: '12:30 PM',
  ),
  ChatDummyModel(
    name: 'Ji Sung',
    profilePic: 'images/profile_4.png',
    lastMessage: 'Great! Thank you so much',
    unreadMessages: 5,
    time: '12:30 PM',
  ),
];
