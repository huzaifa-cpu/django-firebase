

class MessageDummyModel {
  final String message;
  final String time;
  final bool isSender;

  MessageDummyModel({
    required this.message,
    required this.time,
    required this.isSender,
  });
}

final List<MessageDummyModel> messages = [
  MessageDummyModel(
    message: 'Hows the concept',
    time: '9:54 PM',
    isSender: true,
  ),
  MessageDummyModel(
    message: 'Lorem Ipsum is simply dummy text of the printing',
    time: '9:54 PM',
    isSender: true,
  ),
  MessageDummyModel(
    message: 'Lorem Ipsum is simply dummy text of the printing',
    time: '9:54 PM',
    isSender: false,
  ),
  MessageDummyModel(
    message: 'Hows the concept',
    time: '9:54 PM',
    isSender: true,
  ),
  MessageDummyModel(
    message: 'Lorem Ipsum is simply dummy text of the printing',
    time: '9:54 PM',
    isSender: false,
  ),
  MessageDummyModel(
    message: 'Lorem Ipsum is simply dummy text of the printing',
    time: '9:54 PM',
    isSender: false,
  ),
];
