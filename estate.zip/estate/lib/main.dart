// import 'package:estate_mobile_app/static/views/auth/login_page.dart';
// import 'package:estate_mobile_app/static/views/other/splash_page.dart';
// import 'package:estate_mobile_app/static/views/auth/signIn.dart';
// ignore_for_file: prefer_const_constructors, unused_import

import 'package:estate_mobile_app/static/views/auth/forget_password_page.dart';
import 'package:estate_mobile_app/static/views/auth/login_page.dart';
import 'package:estate_mobile_app/static/views/auth/signin_page.dart';
import 'package:estate_mobile_app/static/views/home/appointments/appointment_details_page.dart';
import 'package:estate_mobile_app/static/views/home/appointments/appointments_page.dart';
import 'package:estate_mobile_app/static/views/home/appointments/view_appointment_page.dart';
import 'package:estate_mobile_app/static/views/home/books/books_detail_page.dart';
import 'package:estate_mobile_app/static/views/home/books/books_page.dart';
import 'package:estate_mobile_app/static/views/home/books/chapter_page.dart';
import 'package:estate_mobile_app/static/views/home/books/reading_book_page.dart';
import 'package:estate_mobile_app/static/views/home/books/search_page.dart';
import 'package:estate_mobile_app/static/views/home/calls/video_call_page.dart';
import 'package:estate_mobile_app/static/views/home/calls/voice_call_page.dart';
import 'package:estate_mobile_app/static/views/home/challenges/challenge_details_page.dart';
import 'package:estate_mobile_app/static/views/home/challenges/challenges_page.dart';
import 'package:estate_mobile_app/static/views/home/challenges/finance_page.dart';
import 'package:estate_mobile_app/static/views/home/challenges/leaderboard_page.dart';
import 'package:estate_mobile_app/static/views/home/challenges/profile_page.dart';
import 'package:estate_mobile_app/static/views/home/chats/chat_page.dart';
import 'package:estate_mobile_app/static/views/home/chats/message_page.dart';
import 'package:estate_mobile_app/static/views/home/homes/home_page.dart';
import 'package:estate_mobile_app/static/views/home/more/appearence_page.dart';
import 'package:estate_mobile_app/static/views/home/more/feedback/feedback_page.dart';
import 'package:estate_mobile_app/static/views/home/more/feedback/feedback_response.dart';
import 'package:estate_mobile_app/static/views/home/more/information_&_help/contact_page.dart';
import 'package:estate_mobile_app/static/views/home/more/information_&_help/information_&_help_page.dart';
import 'package:estate_mobile_app/static/views/home/more/more_page.dart';
import 'package:estate_mobile_app/static/views/home/more/my_account_page.dart';
import 'package:estate_mobile_app/static/views/home/payments/payment_details_page.dart';
import 'package:estate_mobile_app/static/views/home/payments/payment_method_page.dart';
import 'package:estate_mobile_app/static/views/home/reports/reports_page.dart';
import 'package:estate_mobile_app/static/views/other/splash_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Estate',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SplashPage(),
    );
  }
}
