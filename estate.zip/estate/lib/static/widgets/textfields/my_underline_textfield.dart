// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

import '../../utils/my_color.dart';

class MyUnderlineTextfield extends StatefulWidget {
  MyUnderlineTextfield({
    Key? key,
    required this.hintText,
  }) : super(key: key);

  String hintText;

  @override
  State<MyUnderlineTextfield> createState() => _MyUnderlineTextfieldState();
}

class _MyUnderlineTextfieldState extends State<MyUnderlineTextfield> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      cursorColor: MyColor.brown2,
      obscureText: true,
      decoration: InputDecoration(
        hintText: widget.hintText,
        hintStyle: TextStyle(color: MyColor.grey1),
        filled: true,
        fillColor: MyColor.grey4,
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.transparent),
          borderRadius: BorderRadius.circular(5),
        ),
        suffixIcon: Icon(
          Icons.visibility_off,
          color: MyColor.black1,
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.transparent),
          borderRadius: BorderRadius.circular(5),
        ),
        contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
      ),
    );
  }
}
