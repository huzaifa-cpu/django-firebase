import 'package:flutter/material.dart';

import '../../utils/my_color.dart';

class CouponTextfield extends StatefulWidget {
  const CouponTextfield({super.key});

  @override
  State<CouponTextfield> createState() => _CouponTextfieldState();
}

class _CouponTextfieldState extends State<CouponTextfield> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      decoration: InputDecoration(
        hintText: 'Coupon Code',
        labelStyle: TextStyle(color: MyColor.blue1),
        contentPadding: EdgeInsets.symmetric(
          vertical: 8.0,
          horizontal: 10.0,
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: MyColor.blue1),
        ),
        focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: MyColor.blue1),
        ),
      ),
    );
  }
}
