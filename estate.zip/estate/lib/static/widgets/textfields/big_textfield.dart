// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

import '../../utils/my_color.dart';

class BigTextField extends StatefulWidget {
  BigTextField({
    Key? key,
    required this.hintText,
  }) : super(key: key);

  String hintText;

  @override
  State<BigTextField> createState() => _BigTextField();
}

class _BigTextField extends State<BigTextField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      // textAlign: TextAlign.left,
      keyboardType: TextInputType.multiline,
      cursorColor: MyColor.brown2,
      decoration: InputDecoration(
        hintText: widget.hintText,
        hintStyle: TextStyle(color: MyColor.grey1),
        // filled: true,
        // fillColor: Colors.grey[350],
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: MyColor.black1),
          borderRadius: BorderRadius.circular(5),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: MyColor.black1),
          borderRadius: BorderRadius.circular(5),
        ),
        contentPadding: EdgeInsets.symmetric(vertical: 50 , horizontal: 10),
        // isCollapsed: true,
        alignLabelWithHint: true,
      ),
    );
  }
}
