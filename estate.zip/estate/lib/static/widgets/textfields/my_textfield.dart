// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';


import '../../utils/my_color.dart';

class MyTextField extends StatefulWidget {
  MyTextField({
    Key? key,
    required this.hintText,
  }) : super(key: key);

  String hintText;

  @override
  State<MyTextField> createState() => _MyTextFieldState();
}

class _MyTextFieldState extends State<MyTextField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      cursorColor: MyColor.brown2,
      decoration: InputDecoration(
        hintText: widget.hintText,
        hintStyle: TextStyle(color: Colors.grey),
        filled: true,
        fillColor: MyColor.grey4,
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.transparent),
          borderRadius: BorderRadius.circular(5),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.transparent),
          borderRadius: BorderRadius.circular(5),
        ),
        contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
      ),
    );
  }
}
