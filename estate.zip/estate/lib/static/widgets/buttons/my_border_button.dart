import 'package:flutter/material.dart';

// import '../../utils/colors.dart';
import '../../utils/my_color.dart';

class MyBorderButton extends StatelessWidget {
  VoidCallback onPressed;

  MyBorderButton({
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ButtonStyle(
        shape: MaterialStateProperty.all<OutlinedBorder>(
          RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(6.0), // Set the desired border radius
            side: BorderSide(
                color: MyColor.blue1), // Set the desired border color
          ),
        ),
        backgroundColor: MaterialStateProperty.all<Color>(MyColor.white1),
        foregroundColor: MaterialStateProperty.all<Color>(MyColor.blue1),
        fixedSize: MaterialStateProperty.all<Size>(
          const Size(230, 50),
        ),
      ),
      child: const Text(
        'REGISTER',
        style: TextStyle(fontSize: 18),
      ),
    );
  }
}
