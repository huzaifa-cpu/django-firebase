import 'dart:async';

import 'package:estate_mobile_app/static/views/auth/login_page.dart';
import 'package:flutter/material.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    startTimer();
  }

  startTimer() async {
    var dur = const Duration(seconds: 2);
    return Timer(dur, route);
  }

  route() {
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: ((context) => LoginPage())));
  }

  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Image.asset('images/estate_logo.png', height: height * 0.3,),
      ),
    );
  }
}