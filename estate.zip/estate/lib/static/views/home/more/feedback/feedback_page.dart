// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/views/home/more/feedback/feedback_response.dart';
import 'package:flutter/material.dart';

import '../../../../widgets/texts/my_text.dart';

class FeedbackPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
         centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.black1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Feedback',
          textStyle: TextStyle(color: MyColor.black1),
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(22, 35, 0, 0),
              child: Text(
                'Did you enjoy ready with Estate app ?',
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
            ),
            SizedBox(height: height * 0.04),
            Column(
              children: [
                ListTile(
                  onTap: () {
                    // Navigator.push(context,
                    // MaterialPageRoute(builder: ((context) => FeedbackResponse())));
                  },
                  title: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Yes',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        'Then why not show it by rating our app.',
                        style: TextStyle(
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                  trailing: Icon(Icons.arrow_forward),
                ),
              ],
            ),
            Divider(),
            ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: ((context) => FeedbackResponse())));
              },
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'No',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    'Then please tell us why your opinion is important to us',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
              trailing: Icon(Icons.arrow_forward),
            ),
          ],
        ),
      ),
    );
  }
}
