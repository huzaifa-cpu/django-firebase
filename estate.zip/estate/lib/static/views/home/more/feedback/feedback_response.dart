// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'dart:ffi';

import 'package:estate_mobile_app/static/widgets/buttons/my_button.dart';
import 'package:estate_mobile_app/static/widgets/textfields/big_textfield.dart';
import 'package:estate_mobile_app/static/widgets/textfields/my_textfield.dart';
import 'package:estate_mobile_app/static/widgets/textfields/my_underline_textfield.dart';
import 'package:estate_mobile_app/static/widgets/textfields/outlined_textfield.dart';
import 'package:estate_mobile_app/static/widgets/textfields/small_textfield.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';
import '../../../../widgets/texts/my_text.dart';

class FeedbackResponse extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
         centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.black1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Feedback',
          textStyle: TextStyle(color: MyColor.black1),
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.fromLTRB(5, 30, 0, 0),
                child: MyText(
                  text: 'Please Describe the problem',
                  textStyle: TextStyle(
                    fontSize: 18,
                  ),
                ),
              ),
              BigTextField(
                hintText: "Description(required)",
              ),
              SizedBox(height: height*0.04),
              MyText(
                text: 'Enter your email address if you would like to revive a reply from us',
                textStyle: TextStyle(
                  fontSize: 18,
                ),
              ),
              SizedBox(height: height*0.02),
              SmallTextfield(hintText: "Email address(optional)"),
              SizedBox(height: height*0.04),
              MyText(
                text: 'The Feedback will be send via unencrypted e-mail to the app owner.',
                textStyle: TextStyle(
                  fontSize: 18,
                ),
              ),
               SizedBox(height: height*0.09),
               Row(
                mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   MyButton(onPressed: (){}, text: "Send"),
                 ],
               )
            ],
          ),
        ),
      ),
    );
  }
}
