// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_key_in_widget_constructors

import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/views/home/more/information_&_help/licenses_page.dart';
import 'package:flutter/material.dart';

import '../../../../widgets/texts/my_text.dart';
import 'contact_page.dart';
import 'data_privacy_page.dart';
import 'imprint_page.dart';

class InformationHelpPage extends StatefulWidget {
  const InformationHelpPage({super.key});

  @override
  State<InformationHelpPage> createState() => _InformationHelpPageState();
}

class _InformationHelpPageState extends State<InformationHelpPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.black1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Information & Help',
          textStyle: MyStyle.black1_25_800,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Divider(
              color: MyColor.grey1.withOpacity(0.5),
              thickness: 1.0,
            ),
            ListTile(
              onTap: () {},
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                    text: 'Software Version',
                    textStyle: MyStyle.black1_18_000,
                    // style: TextStyle(fontSize: 18),
                  ),
                ],
              ),
              trailing: MyText(
                text: "5.10.1(3959",
                textStyle: MyStyle.grey1_17_000,
                // textStyle: TextStyle(color: Colors.grey, fontSize: 16),
              ),
            ),
            Divider(
              color: MyColor.grey1.withOpacity(0.5),
              thickness: 1.0,
            ),
            ListTile(
              onTap: () {},
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                    text: 'Code Version',
                    textStyle: MyStyle.black1_18_000,
                  ),
                ],
              ),
              trailing: MyText(
                text: "e980760e3",
                textStyle: MyStyle.grey1_17_000,
              ),
            ),
            Divider(
              color: MyColor.grey1.withOpacity(0.5),
              thickness: 1.0,
            ),
            ListTile(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: ((context) => LicensesPage())));
              },
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                    text: 'Licenses',
                    textStyle: MyStyle.black1_18_000,
                  ),
                ],
              ),
              trailing: Icon(
                Icons.arrow_forward_ios,
                size: 18,
                color: MyColor.black1,
              ),
            ),
            Divider(
              color: MyColor.grey1.withOpacity(0.5),
              thickness: 1.0,
            ),
            ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: ((context) => ContactPage())));
              },
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                    text: 'Contact',
                    textStyle: MyStyle.black1_18_000,
                  ),
                ],
              ),
              trailing: Icon(
                Icons.arrow_forward_ios,
                size: 18,
                color: MyColor.black1,
              ),
            ),
            Divider(
              color: MyColor.grey1.withOpacity(0.5),
              thickness: 1.0,
            ),
            ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: ((context) => ImprintPage())));
              },
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                    text: 'Imprint',
                    textStyle: MyStyle.black1_18_000,
                  ),
                ],
              ),
              trailing: Icon(
                Icons.arrow_forward_ios,
                size: 18,
                color: MyColor.black1,
              ),
            ),
            Divider(
              color: MyColor.grey1.withOpacity(0.5),
              thickness: 1.0,
            ),
            ListTile(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: ((context) => DataPrivacyPage())));
              },
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                    text: 'Data Privacy',
                    textStyle: MyStyle.black1_18_000,
                  ),
                ],
              ),
              trailing: Icon(
                Icons.arrow_forward_ios,
                size: 18,
                color: MyColor.black1,
              ),
            ),
            Divider(
              color: MyColor.grey1.withOpacity(0.5),
              thickness: 1.0,
            ),
          ],
        ),
      ),
    );
  }
}
