// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_key_in_widget_constructors

import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:flutter/material.dart';

import '../../../../widgets/texts/my_text.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.black1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Contact',
          textStyle: MyStyle.black1_25_800,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Divider(
              color: MyColor.grey1.withOpacity(0.5),
              thickness: 1.0,
            ),
            ListTile(
              onTap: () {},
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                    text: 'Email',
                    textStyle: MyStyle.black1_16_000,
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: 'ebook@estate.de',
                    textStyle: MyStyle.black1_16_000,
                  ),
                ],
              ),
              // trailing: Icon(Icons.arrow_forward),
            ),
            Divider(
              color: MyColor.grey1.withOpacity(0.5),
              thickness: 1.0,
            ),
            ListTile(
              onTap: () {},
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                    text: 'Hotline',
                    textStyle: MyStyle.black1_16_000,
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: '+49(0)89-30 757 900',
                    textStyle: MyStyle.black1_16_000,
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: 'English speaking customer care : ',
                    textStyle: MyStyle.black1_16_000,
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: 'Monday to Saturday 9 a.m to 8 p.m',
                    textStyle: MyStyle.black1_16_000,
                  ),
                ],
              ),
              // trailing: Icon(Icons.arrow_forward),
            ),
          ],
        ),
      ),
    );
  }
}
