// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_key_in_widget_constructors

import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:flutter/material.dart';

import '../../../../widgets/texts/my_text.dart';

class ImprintPage extends StatefulWidget {
  const ImprintPage({super.key});

  @override
  State<ImprintPage> createState() => _ImprintPageState();
}

class _ImprintPageState extends State<ImprintPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.black1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Imprint',
          textStyle: MyStyle.black1_25_800,
        ),
        elevation: 0,
      ),
    );
  }
}
