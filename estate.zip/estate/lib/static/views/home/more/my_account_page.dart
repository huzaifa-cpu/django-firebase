// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:estate_mobile_app/static/widgets/textfields/my_static_textfield.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/texts/my_text.dart';

class MyAccountPage extends StatefulWidget {
  const MyAccountPage({super.key});

  @override
  State<MyAccountPage> createState() => _MyAccountPageState();
}

class _MyAccountPageState extends State<MyAccountPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.black1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'My Account',
          textStyle: MyStyle.black1_25_800,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              StaticTextfield(hintText: "arsalanali4465"),
              SizedBox(height: height * 0.03),
              StaticTextfield(
                hintText: "Arsalan Ali Shah",
                suffixIcon: Icon(
                  Icons.edit,
                  color: MyColor.black1,
                ),
              ),
              SizedBox(height: height * 0.03),
              StaticTextfield(
                  hintText: "arsalanali4465@gmail.com",
                  suffixIcon: Icon(
                    Icons.edit,
                    color: MyColor.black1,
                  )),
              SizedBox(height: height * 0.03),
              StaticTextfield(
                  hintText: "*********************",
                  suffixIcon: Icon(
                    Icons.visibility_off,
                    color: MyColor.black1,
                  )),
              SizedBox(height: height * 0.03),
            ],
          ),
        ),
      ),
    );
  }
}
