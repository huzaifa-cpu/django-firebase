// ignore_for_file: prefer_const_constructors

import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/views/home/more/appearence_page.dart';
import 'package:estate_mobile_app/static/views/home/more/feedback/feedback_page.dart';
import 'package:estate_mobile_app/static/views/home/more/information_&_help/information_&_help_page.dart';
import 'package:estate_mobile_app/static/views/home/more/my_account_page.dart';
import 'package:estate_mobile_app/static/widgets/texts/my_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class MorePage extends StatefulWidget {
  const MorePage({super.key});

  @override
  State<MorePage> createState() => _MorePageState();
}

class _MorePageState extends State<MorePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.fromLTRB(8, 55, 18, 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(24, 25, 0, 0),
              child: MyText(
                text: 'More',
                textStyle: TextStyle(
                  fontSize: 33,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 35),
            GestureDetector(
              onTap: (() {
                Navigator.push(context,
                    MaterialPageRoute(builder: ((context) => MyAccountPage())));
              }),
              child: ListTile(
                leading: Icon(Icons.account_circle_outlined,
                    size: 35, color: MyColor.black1),
                title: MyText(
                  text: 'My Account',
                  textStyle: TextStyle(fontSize: 20),
                ),
              ),
            ),
            SizedBox(height: 10),
            GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: ((context) => AppearencePage())));
              },
              child: ListTile(
                leading: Icon(Icons.settings_outlined,
                    size: 35, color: MyColor.black1),
                title: MyText(
                  text: 'Appearence',
                  textStyle: TextStyle(fontSize: 20),
                ),
              ),
            ),
            SizedBox(height: 10),
            GestureDetector(
              onTap: (() {
                Navigator.push(context,
                    MaterialPageRoute(builder: ((context) => FeedbackPage())));
              }),
              child: ListTile(
                leading: Icon(Icons.feedback, size: 35, color: MyColor.black1),
                title: MyText(
                  text: 'Feedback',
                  textStyle: TextStyle(fontSize: 20),
                ),
              ),
            ),
            SizedBox(height: 10),
            GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: ((context) => InformationHelpPage())));
              },
              child: ListTile(
                leading: Icon(Icons.help, size: 35, color: MyColor.black1),
                title: MyText(
                  text: 'Information & Help',
                  textStyle: TextStyle(fontSize: 20),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
