// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_key_in_widget_constructors

import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:flutter/material.dart';
import 'package:selectable_container/selectable_container.dart';

import '../../../widgets/cards/image_card.dart';
import '../../../widgets/texts/my_text.dart';

class AppearencePage extends StatefulWidget {
  @override
  State<AppearencePage> createState() => _AppearencePageState();
}

class _AppearencePageState extends State<AppearencePage> {
  int selectedImageIndex = 0; // Track the index of the selected image

  void selectImage(int index) {
    setState(() {
      selectedImageIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.black1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Appearence',
          textStyle: MyStyle.black1_25_800,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: height * 0.03,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SelectableContainer(
                  onValueChanged: (value) {
                    if (value) {
                      selectImage(0); // Select the first image
                    }
                  },
                  selected: selectedImageIndex == 0,
                  selectedBorderColor: MyColor.black1,
                  selectedBackgroundColorIcon: MyColor.black1,
                  unselectedBorderColor: Colors.transparent,
                  child: ImageCard(
                    image: 'images/light_image.png',
                    // text: 'Light',
                  ),
                ),
                SelectableContainer(
                  onValueChanged: (value) {
                    if (value) {
                      selectImage(1); // Select the first image
                    }
                  },
                  selected: selectedImageIndex == 1,
                  selectedBorderColor: MyColor.black1,
                  selectedBackgroundColorIcon: MyColor.black1,
                  unselectedBorderColor: Colors.transparent,
                  child: ImageCard(
                    image: 'images/dark_image.png',
                    // text: 'Dark ',
                  ),
                ),
                SelectableContainer(
                  onValueChanged: (value) {
                    if (value) {
                      selectImage(2); // Select the first image
                    }
                  },
                  selected: selectedImageIndex == 2,
                  selectedBorderColor: MyColor.black1,
                  selectedBackgroundColorIcon: MyColor.black1,
                  unselectedBorderColor: Colors.transparent,
                  child: ImageCard(
                    image: 'images/system_image.png',
                    // text: 'System',
                  ),
                ),
              ],
            ),
            SizedBox(height: height * 0.02),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                MyText(text: "Light", textStyle: MyStyle.black1_19_000),
                SizedBox(width: width * 0.02),
                MyText(text: "Dark", textStyle: MyStyle.black1_19_000),
                SizedBox(width: width * 0.02),
                MyText(text: "System", textStyle: MyStyle.black1_19_000),
              ],
            ),
            SizedBox(height: height * 0.06),
            Padding(
              padding: const EdgeInsets.all(25.0),
              child: Column(
                children: [
                  MyText(
                    text:
                        'The "automatic" appearence follows the setting of your operating system',
                    textStyle: TextStyle(
                      fontSize: 18,
                    ),
                  ),
                  SizedBox(height: height * 0.04),
                  MyText(
                    text:
                        'Additionally, you can customize the background color of the book by adjusting the font settings. The adjustments inside the book do not change the appearance of the app.',
                    textStyle: TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
