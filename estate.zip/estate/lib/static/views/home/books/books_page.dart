import 'package:estate_mobile_app/static/views/home/books/search_page.dart';
import 'package:estate_mobile_app/static/views/home/books/tabs/author_tab.dart';
import 'package:estate_mobile_app/static/views/home/books/tabs/collection_tab.dart';
import 'package:estate_mobile_app/static/views/home/books/tabs/podcast_tab.dart';
import 'package:estate_mobile_app/static/views/home/books/tabs/title_tab.dart';
import 'package:estate_mobile_app/static/views/home/books/widgets/custom_tabbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/texts/my_text.dart';

class BooksPage extends StatefulWidget {
  const BooksPage({super.key});

  @override
  State<BooksPage> createState() => _BooksPageState();
}

class _BooksPageState extends State<BooksPage> {
  bool titles = true;
  bool authors = false;
  bool collections = false;
  bool podcast = false;

  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: MyColor.white1,
      body: Column(
        children: [
          SizedBox(
            height: height * 0.06,
          ),
          Row(
            children: [
              IconButton(
                icon: Icon(
                  Icons.arrow_back,
                  color: MyColor.black1,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              SizedBox(
                width: width * 0.05,
              ),
              MyText(
                text: 'Books',
                textStyle: MyStyle.black1_26_400,
              ),
              Spacer(),
              IconButton(
                icon: Icon(
                  Icons.search,
                  color: MyColor.black1,
                ),
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: ((context) => SearchPage())));
                },
              ),
              IconButton(
                icon: Icon(
                  Icons.more_vert,
                  color: MyColor.black1,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              )
            ],
          ),
          SizedBox(
            height: height * 0.01,
          ),
          Padding(
              padding: const EdgeInsets.all(10.0),
              child: CustomTabbar(
                  titles: titles,
                  authors: authors,
                  collections: collections,
                  podcast: podcast,
                  titlePressed: () {
                    setState(() {
                      titles = true;
                      authors = false;
                      collections = false;
                      podcast = false;
                    });
                  },
                  authorPressed: () {
                    setState(() {
                      titles = false;
                      authors = true;
                      collections = false;
                      podcast = false;
                    });
                  },
                  collectionPressed: () {
                    setState(() {
                      titles = false;
                      authors = false;
                      collections = true;
                      podcast = false;
                    });
                  },
                  podcastPressed: () {
                    setState(() {
                      titles = false;
                      authors = false;
                      collections = false;
                      podcast = true;
                    });
                  })),
          titles
              ? TitleTab()
              : authors
                  ? AuthorTab()
                  : collections
                      ? CollectionTab()
                      : podcast
                          ? PodcastTab()
                          : Container()
        ],
      ),
    );
  }
}
