//detail screen

// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_key_in_widget_constructors
import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/views/home/books/chapter_page.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_custom_button.dart';
import 'package:flutter/material.dart';

import '../../../widgets/texts/my_text.dart';

class BooksDetailPage extends StatefulWidget {
  const BooksDetailPage({Key? key}) : super(key: key);

  @override
  State<BooksDetailPage> createState() => _BooksDetailPageState();
}

class _BooksDetailPageState extends State<BooksDetailPage> {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                children: [
                  Center(
                    child: Image.asset(
                      'images/book_image.png',
                      // Replace with the actual path to the book image
                      height: width * 0.5, // Adjust the height as needed
                    ),
                  ),
                  SizedBox(height: height * 0.015),
                  Center(
                      child: MyText(
                          text: 'Debit Reduction',
                          textStyle: MyStyle.black1_18_700)),
                  SizedBox(height: height * 0.006),
                  Center(
                      child: MyText(
                          text: 'By Nikos Milonas',
                          textStyle: MyStyle.black1_15_200)),
                  SizedBox(height: height * 0.006),
                  Center(
                      child: MyText(
                          text: '3 Chapters', textStyle: MyStyle.black1_15_200)),
                  SizedBox(height: height * 0.04),
                  Center(
                    child: MyCustomButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: ((context) => ChapterPage())));
                        },
                        text: "READ BOOK",
                        width: width * 0.7,
                        height: height * 0.042,
                        textStyle: MyStyle.white1_16_700,
                        color: MyColor.brown1),
                  ),
                  SizedBox(height: height * 0.04),
                  MyText(text: "What's inside ?", textStyle: MyStyle.black1_18_700),
                  SizedBox(height: height * 0.0005),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 13.0),
                    child: MyText(
                      text:
                      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. ",
                      textStyle: MyStyle.black1_15_200,
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                        color: MyColor.grey7,
                        borderRadius: BorderRadius.circular(8)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        MyText(
                            text: "You'll learn", textStyle: MyStyle.black1_18_700),
                        SizedBox(height: height * 0.02),
                        Row(
                          children: [
                            Icon(Icons.check, color: MyColor.blue3),
                            SizedBox(width: width * 0.02),
                            MyText(
                              text: 'Why you might need to change your job',
                              textStyle: MyStyle.black1_15_200,
                            ),
                          ],
                        ),
                        SizedBox(height: height * 0.01),
                        Row(
                          children: [
                            Icon(Icons.check, color: MyColor.blue3),
                            SizedBox(width: width * 0.02),
                            MyText(
                              text: 'Why you might need to change your job',
                              textStyle: MyStyle.black1_15_200,
                            ),
                          ],
                        ),
                        SizedBox(height: height * 0.01),
                        Row(
                          children: [
                            Icon(Icons.check, color: MyColor.blue3),
                            SizedBox(width: width * 0.02),
                            MyText(
                              text: 'Why you might need to change your job',
                              textStyle: MyStyle.black1_15_200,
                            ),
                          ],
                        ),
                        SizedBox(height: height * 0.01),
                        Row(
                          children: [
                            Icon(Icons.check, color: MyColor.blue3),
                            SizedBox(width: width * 0.02),
                            MyText(
                              text: 'Why you might need to change your job',
                              textStyle: MyStyle.black1_15_200,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: height * 0.02),
                  MyText(text: "Chapters", textStyle: MyStyle.black1_16_600),
                  SizedBox(height: height * 0.01),
                  chapterLayout("Debit consolidation", true),
                  SizedBox(height: height * 0.01),
                  chapterLayout("Refinancing", false),
                  SizedBox(height: height * 0.01),
                  chapterLayout("Refinancing", false),
                  SizedBox(height: height * 0.03),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              color: MyColor.grey7,
              // height: height * 0.05,
              width: width,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(
                    Icons.info_outline,
                    color: MyColor.brown1,
                    size: 25,
                  ),
                  SizedBox(width: width * 0.04),
                  MyText(
                      text: "How can i get an ebook?",
                      textStyle: MyStyle.black1_16_000),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: height * 0.02),
                  MyText(text: "Synopsis", textStyle: MyStyle.black1_16_600),
                  SizedBox(height: height * 0.01),
                  MyText(text: "-", textStyle: MyStyle.black1_16_600),
                  SizedBox(height: height * 0.02),
                  MyText(
                      text: "Book details", textStyle: MyStyle.black1_16_600),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: 'ISBN: 974568316544513',
                    textStyle: MyStyle.black1_15_200,
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: 'Format: EPUB',
                    textStyle: MyStyle.black1_15_200,
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: 'FileSize: NaN MB',
                    textStyle: MyStyle.black1_15_200,
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: 'Publisher: -',
                    textStyle: MyStyle.black1_15_200,
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: 'Family Sharing: -',
                    textStyle: MyStyle.black1_15_200,
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text: 'Duration: -',
                    textStyle: MyStyle.black1_15_200,
                  ),
                  SizedBox(height: height * 0.01),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget chapterLayout(String text, bool isExpanded) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: () {
        isExpanded = !isExpanded;
      },
      child: Column(
        children: [
          SizedBox(
            width: width,
            height: height * 0.08,
            child: Card(
              color: MyColor.grey7,
              child: Row(
                children: [
                  SizedBox(
                    width: width * 0.01,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Container(
                      width: width * 0.013,
                      color: MyColor.blue1,
                      height: height * 0.15,
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MyText(text: text, textStyle: MyStyle.black1_16_000),
                    ],
                  ),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Icon(Icons.keyboard_arrow_down,
                              color: MyColor.black1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          isExpanded
              ? Container(
                  color: MyColor.cream2,
                  padding: EdgeInsets.all(15),
                  margin: EdgeInsets.symmetric(horizontal: 5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      MyText(
                          text: "Key points", textStyle: MyStyle.black1_16_600),
                      SizedBox(height: height * 0.02),
                      Row(
                        children: [
                          Column(
                            children: [
                              MyText(
                                  text: "1", textStyle: MyStyle.blue3_15_700),
                              SizedBox(height: height * 0.04),
                              MyText(
                                  text: "2", textStyle: MyStyle.blue3_15_700),
                              SizedBox(height: height * 0.04),
                              MyText(
                                  text: "3", textStyle: MyStyle.blue3_15_700),
                              SizedBox(height: height * 0.04),
                              MyText(
                                  text: "3", textStyle: MyStyle.blue3_15_700),
                            ],
                          ),
                          SizedBox(width: width * 0.08),
                          Column(
                            children: [
                              MyText(
                                text: 'Why you might need to change your job',
                                textStyle: MyStyle.black1_15_200,
                              ),
                              Divider(
                                color: MyColor.black1,
                                height: height * 0.04,
                              ),
                              MyText(
                                text: 'Why you might need to change your job',
                                textStyle: MyStyle.black1_15_200,
                              ),
                              SizedBox(height: height * 0.04),
                              MyText(
                                text: 'Why you might need to change your job',
                                textStyle: MyStyle.black1_15_200,
                              ),
                              SizedBox(height: height * 0.04),
                              MyText(
                                text: 'Why you might need to change your job',
                                textStyle: MyStyle.black1_15_200,
                              ),
                            ],
                          )
                        ],
                      )
                    ],
                  ),
                )
              : Container()
        ],
      ),
    );
  }
}
