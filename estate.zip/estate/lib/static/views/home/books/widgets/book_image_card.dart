import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/widgets/texts/my_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BookImageCard extends StatefulWidget {
  bool isShowDownload;
  String name;
  VoidCallback onPressed;

  BookImageCard(
      {super.key,
      required this.isShowDownload,
      required this.name,
      required this.onPressed});

  @override
  State<BookImageCard> createState() => _BookImageCardState();
}

class _BookImageCardState extends State<BookImageCard> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: widget.onPressed,
      child: Container(
        width: width * 0.47,
        color: MyColor.white1,
        padding: EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Image.asset(
                  'images/book_image.png',
                  height: height * 0.31,
                  width: width * 0.5,
                  fit: BoxFit.fill, //
                ),
                widget.isShowDownload
                    ? Row(
                        children: [
                          Spacer(),
                          Container(
                            padding: EdgeInsets.all(5),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(100.0),
                                child: Icon(
                                  Icons.cloud_download,
                                  color: MyColor.brown1,
                                )),
                            margin: EdgeInsets.only(top: 10, right: 10),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: MyColor.brown1,
                                width: 1.0,
                              ),
                              color: MyColor.white1,
                              borderRadius: BorderRadius.circular(100),
                            ),
                          ),
                        ],
                      )
                    : Container()
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                    flex: 4,
                    child: MyText(
                        text: widget.name, textStyle: MyStyle.black1_16_000)),
                // Spacer(),
                IconButton(
                  icon: Icon(
                    Icons.more_vert,
                    size: height * 0.026,
                  ),
                  onPressed: () {},
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
