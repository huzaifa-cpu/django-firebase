import 'package:estate_mobile_app/static/views/home/books/reading_book_page.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';

class BookCard extends StatefulWidget {
  @override
  State<BookCard> createState() => _BookCardState();
}

class _BookCardState extends State<BookCard> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            BookCardLayout(
                "Debit consolidation", Icons.done_all, MyColor.brown1),
            BookCardLayout("Refinancing", Icons.done_all, MyColor.brown1),
            BookCardLayout(
                "Refinancing", Icons.arrow_forward_ios, MyColor.brown1),
          ],
        ),
      ),
    );
  }

  Widget BookCardLayout(String text, IconData iconData, Color iconColor) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: () {
        Navigator.push(context,
            MaterialPageRoute(builder: ((context) => ReadingBookPage())));
      },
      child: SizedBox(
        width: width,
        height: height * 0.09,
        child: Card(
          color: MyColor.grey7,
          child: Row(
            children: [
              SizedBox(
                width: width * 0.01,
              ),
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Container(
                  width: width * 0.013,
                  color: MyColor.brown1,
                  height: height * 0.15,
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  MyText(text: text, textStyle: MyStyle.black1_16_600),
                ],
              ),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Icon(iconData, color: iconColor),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
