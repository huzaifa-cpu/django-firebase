import 'package:flutter/cupertino.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';

class CustomTabbar extends StatefulWidget {
  bool titles;
  bool authors;
  bool collections;
  bool podcast;
  VoidCallback titlePressed;
  VoidCallback authorPressed;
  VoidCallback collectionPressed;
  VoidCallback podcastPressed;

  CustomTabbar({
    super.key,
    required this.titles,
    required this.authors,
    required this.collections,
    required this.podcast,
    required this.titlePressed,
    required this.authorPressed,
    required this.collectionPressed,
    required this.podcastPressed,
  });

  @override
  State<CustomTabbar> createState() => _CustomTabbarState();
}

class _CustomTabbarState extends State<CustomTabbar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 3),
      decoration: BoxDecoration(
        color: MyColor.grey4,
        borderRadius: BorderRadius.circular(100.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: widget.titlePressed,
            child: Container(
              padding: widget.titles
                  ? const EdgeInsets.symmetric(vertical: 6.0, horizontal: 22)
                  : const EdgeInsets.symmetric(vertical: 6.0, horizontal: 10),
              decoration: BoxDecoration(
                color: widget.titles ? MyColor.white1 : MyColor.grey4,
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: MyText(
                  text: "Titles",
                  textStyle: widget.titles
                      ? MyStyle.blue1_16_600
                      : MyStyle.grey6_17_400),
            ),
          ),
          GestureDetector(
            onTap: widget.authorPressed,
            child: Container(
              padding: widget.authors
                  ? const EdgeInsets.symmetric(vertical: 6.0, horizontal: 22)
                  : const EdgeInsets.symmetric(vertical: 6.0, horizontal: 10),
              decoration: BoxDecoration(
                color: widget.authors ? MyColor.white1 : MyColor.grey4,
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: MyText(
                  text: "Authors",
                  textStyle: widget.authors
                      ? MyStyle.blue1_16_600
                      : MyStyle.grey6_17_400),
            ),
          ),
          GestureDetector(
            onTap: widget.collectionPressed,
            child: Container(
              padding: widget.collections
                  ? const EdgeInsets.symmetric(vertical: 6.0, horizontal: 22)
                  : const EdgeInsets.symmetric(vertical: 6.0, horizontal: 10),
              decoration: BoxDecoration(
                color: widget.collections ? MyColor.white1 : MyColor.grey4,
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: MyText(
                  text: "Collections",
                  textStyle: widget.collections
                      ? MyStyle.blue1_16_600
                      : MyStyle.grey6_17_400),
            ),
          ),
          GestureDetector(
            onTap: widget.podcastPressed,
            child: Container(
              padding: widget.podcast
                  ? const EdgeInsets.symmetric(vertical: 6.0, horizontal: 22)
                  : const EdgeInsets.symmetric(vertical: 6.0, horizontal: 10),
              decoration: BoxDecoration(
                color: widget.podcast ? MyColor.white1 : MyColor.grey4,
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: MyText(
                  text: "Podcast",
                  textStyle: widget.podcast
                      ? MyStyle.blue1_16_600
                      : MyStyle.grey6_17_400),
            ),
          ),
        ],
      ),
    );
  }
}
