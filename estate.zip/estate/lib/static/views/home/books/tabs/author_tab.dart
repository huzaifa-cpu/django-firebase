import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';

class AuthorTab extends StatefulWidget {
  const AuthorTab({super.key});

  @override
  State<AuthorTab> createState() => _AuthorTabState();
}

class _AuthorTabState extends State<AuthorTab> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          IconButton(
            icon: Icon(
              Icons.arrow_upward,
              color: MyColor.brown1,
              size: 25,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          SizedBox(
            height: height * 0.03,
          ),
          ListTile(
            onTap: () {},
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                MyText(
                  text: 'Haig, Matt',
                  textStyle: MyStyle.black1_20_800,
                  // style: TextStyle(fontSize: 18),
                ),
                MyText(
                  text: "1 BOOK",
                  textStyle: MyStyle.grey1_17_000,
                  // textStyle: TextStyle(color: Colors.grey, fontSize: 16),
                ),
              ],
            ),
          ),
          SizedBox(height: height * 0.02,),
          Divider(
            color: MyColor.grey1.withOpacity(0.5),
            thickness: 1.0,
          ),ListTile(
            onTap: () {},
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                MyText(
                  text: 'Nguyen-kim, Dr. Mai Thi',
                  textStyle: MyStyle.black1_20_800,
                  // style: TextStyle(fontSize: 18),
                ),
                MyText(
                  text: "1 BOOK",
                  textStyle: MyStyle.grey1_17_000,
                  // textStyle: TextStyle(color: Colors.grey, fontSize: 16),
                ),
              ],
            ),
          ),
          SizedBox(height: height * 0.02,),
          Divider(
            color: MyColor.grey1.withOpacity(0.5),
            thickness: 1.0,
          ),ListTile(
            onTap: () {},
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                MyText(
                  text: 'Rossmann, Dirk',
                  textStyle: MyStyle.black1_20_800,
                  // style: TextStyle(fontSize: 18),
                ),
                MyText(
                  text: "1 BOOK",
                  textStyle: MyStyle.grey1_17_000,
                  // textStyle: TextStyle(color: Colors.grey, fontSize: 16),
                ),
              ],
            ),
          ),
          SizedBox(height: height * 0.02,),
          Divider(
            color: MyColor.grey1.withOpacity(0.5),
            thickness: 1.0,
          )
        ],
      ),
    );
  }
}
