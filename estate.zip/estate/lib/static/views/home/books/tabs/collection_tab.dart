import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/widgets/texts/my_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';

class CollectionTab extends StatefulWidget {
  const CollectionTab({super.key});

  @override
  State<CollectionTab> createState() => _CollectionTabState();
}

class _CollectionTabState extends State<CollectionTab> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                icon: Icon(
                  Icons.arrow_upward,
                  color: MyColor.brown1,
                  size: 25,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              SizedBox(
                width: width * 0.05,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 25, vertical: 5),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: MyColor.blue1,
                    width: 1.0,
                  ),
                  color: MyColor.white1,
                  borderRadius: BorderRadius.circular(100),
                ),
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(100.0),
                    child: Row(
                      children: [
                        Icon(
                          Icons.add,
                          color: MyColor.blue1,
                        ),
                        SizedBox(
                          width: width * 0.01,
                        ),
                        MyText(
                            text: "CREATE COLLECTION",
                            textStyle: MyStyle.blue1_16_600)
                      ],
                    )),
              ),
            ],
          ),
          SizedBox(
            height: height * 0.15,
          ),
          Center(
            child: Image.asset(
              'images/estate_logo.png',
              height: height * 0.2,
            ),
          ),
          MyText(
              text: "No Collection have been created",
              textStyle: MyStyle.grey1_17_000),
          MyText(
              text: "yet. Collections make it easier for",
              textStyle: MyStyle.grey1_17_000),
          MyText(
              text: "you to organize your titles",
              textStyle: MyStyle.grey1_17_000),
        ],
      ),
    );
  }
}
