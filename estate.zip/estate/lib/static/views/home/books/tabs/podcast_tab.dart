import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';
import '../widgets/book_image_card.dart';

class PodcastTab extends StatefulWidget {
  const PodcastTab({super.key});

  @override
  State<PodcastTab> createState() => _PodcastTabState();
}

class _PodcastTabState extends State<PodcastTab> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Row(
            children: [
              BookImageCard(
                isShowDownload: false,
                name: "Cross Down",
                onPressed: () {},
              ),
              BookImageCard(
                isShowDownload: false,
                name: "The last thing he told me",
                onPressed: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}
