import 'package:estate_mobile_app/static/views/home/books/books_detail_page.dart';
import 'package:estate_mobile_app/static/views/home/books/widgets/book_image_card.dart';
import 'package:estate_mobile_app/static/widgets/bottom_sheet/filter_sheet.dart';
import 'package:estate_mobile_app/static/widgets/bottom_sheet/sort_sheet.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/cards/image_card.dart';
import '../../../../widgets/texts/my_text.dart';

class TitleTab extends StatefulWidget {
  const TitleTab({super.key});

  @override
  State<TitleTab> createState() => _TitleTabState();
}

class _TitleTabState extends State<TitleTab> {

  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery
        .of(context)
        .size
        .height;
    var width = MediaQuery
        .of(context)
        .size
        .width;
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                icon: Icon(
                  Icons.arrow_upward,
                  color: MyColor.brown1,
                  size: 25,
                ),
                onPressed: () {
                  showModalBottomSheet(
                    backgroundColor: Colors.transparent,
                    context: context,
                    builder: (BuildContext context) {
                      return SortSheet();
                    },
                  );
                },
              ),
              SizedBox(
                width: width * 0.05,
              ),
              MyText(
                text: 'Filters',
                textStyle: MyStyle.black1_19_000,
              ),
              SizedBox(
                width: width * 0.05,
              ),
              IconButton(
                icon: Icon(
                  Icons.keyboard_arrow_down_sharp,
                  color: MyColor.brown1,
                ),
                onPressed: () {
                  showModalBottomSheet(
                    backgroundColor: Colors.transparent,
                    context: context,
                    builder: (BuildContext context) {
                      return FilterSheet();
                    },
                  );
                },
              ),
            ],
          ),
          SizedBox(
              height: height * 0.702,
              child: ListView.builder(
                  itemCount: 3,
                  // physics: ClampingScrollPhysics(),
                  itemBuilder: (context, index) {
                    return Row(
                      children: [
                        BookImageCard(
                          isShowDownload: true,
                          name: "Cross Down",
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: ((context) => BooksDetailPage())));
                          },
                        ),
                        BookImageCard(
                            isShowDownload: true,
                            name: "The last thing he told me",
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: ((context) =>
                                          BooksDetailPage())));
                            }),
                      ],
                    );
                  })),

        ],
      ),
    );
  }
}
