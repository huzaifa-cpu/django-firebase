// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_key_in_widget_constructors

import 'package:estate_mobile_app/static/views/home/books/widgets/book_card.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_style.dart';
import '../../../widgets/texts/my_text.dart';

class ChapterPage extends StatefulWidget {
  const ChapterPage({super.key});

  @override
  State<ChapterPage> createState() => _ChapterPageState();
}

class _ChapterPageState extends State<ChapterPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: MyText(
          text: 'Debit Reduction',
          textStyle: MyStyle.black1_25_800,
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: height * 0.03),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 17),
            child: MyText(
              text: 'Chapters',
              textStyle: MyStyle.black1_20_800,
            ),
          ),
          Expanded(
            child: BookCard(),
          ),
        ],
      ),
    );
  }
}
