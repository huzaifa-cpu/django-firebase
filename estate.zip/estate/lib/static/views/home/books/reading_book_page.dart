import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/widgets/texts/my_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';

class ReadingBookPage extends StatefulWidget {
  const ReadingBookPage({super.key});

  @override
  State<ReadingBookPage> createState() => _ReadingBookPageState();
}

class _ReadingBookPageState extends State<ReadingBookPage> {
  int _currentPage = 1;
  int _totalPages = 5;
  bool _isSidebarVisible = false;
  bool showSearch = false;

  void goToPreviousPage() {
    if (_currentPage > 1) {
      setState(() {
        _currentPage--;
      });
    }
  }

  void goToNextPage() {
    if (_currentPage < _totalPages) {
      setState(() {
        _currentPage++;
      });
    }
  }

  void toggleSidebarVisibility() {
    setState(() {
      _isSidebarVisible = !_isSidebarVisible;
    });
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: MyColor.white1,
      body: GestureDetector(
        onTap: toggleSidebarVisibility,
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 13.0, vertical: 50),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    showSearch
                        ? Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              IconButton(
                                icon: Icon(
                                  Icons.close,
                                  color: MyColor.grey6,
                                  size: 35,
                                ),
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                              ),
                              SizedBox(
                                width: width * 0.01,
                              ),
                              searchBar()
                            ],
                          )
                        : Container(),
                    SizedBox(
                      height: height * 0.05,
                    ),
                    MyText(
                        text: """ Helen's War """,
                        textStyle: MyStyle.black1_30_800),
                    SizedBox(
                      height: height * 0.04,
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: Text(
                          textAlign: TextAlign.center,
                          """What is Lorem Ipsum?
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.What is Lorem Ipsum?
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer """,
                          style: MyStyle.black1_16_000),
                    )
                  ],
                ),
              ),
              AnimatedPositioned(
                duration: Duration(milliseconds: 200),
                curve: Curves.easeInOut,
                top: 0.0,
                bottom: 0.0,
                right: _isSidebarVisible ? 0.0 : -80.0,
                child: Container(
                  decoration: BoxDecoration(
                    color: MyColor.blue1,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        bottomLeft: Radius.circular(20)),
                  ),
                  margin:
                      EdgeInsets.symmetric(vertical: showSearch ? 270 : 250),
                  width: 80.0,
                  height: height * 0.005,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        padding: EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: MyColor.white1,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: IconButton(
                          icon: Icon(Icons.sort_by_alpha,
                              color: MyColor.brown1, size: 27),
                          onPressed: () {
                            // Implement search functionality
                          },
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: MyColor.white1,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: IconButton(
                          icon: Icon(Icons.bookmark_remove_sharp,
                              color: MyColor.brown1, size: 27),
                          onPressed: () {
                            // Implement search functionality
                          },
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: MyColor.white1,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: IconButton(
                          icon: Icon(Icons.screen_search_desktop_sharp,
                              color: MyColor.brown1, size: 27),
                          onPressed: () {
                            setState(() {
                              showSearch = !showSearch;
                            });
                          },
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: MyColor.white1,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: IconButton(
                          icon: Icon(Icons.volume_up_sharp,
                              color: MyColor.brown1, size: 27),
                          onPressed: () {
                            // Implement search functionality
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 45.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(
                  Icons.arrow_back_ios,
                  size: 20,
                ),
                onPressed: goToPreviousPage,
              ),
              Row(
                children: List<Widget>.generate(
                  _totalPages,
                  (index) => Container(
                    decoration: BoxDecoration(
                      color: (index + 1) == _currentPage
                          ? MyColor.brown1
                          : MyColor.white1,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    margin: EdgeInsets.symmetric(vertical: 2, horizontal: 2),
                    padding: EdgeInsets.symmetric(vertical: 2, horizontal: 6),
                    child: MyText(
                      text: (index + 1).toString(),
                      textStyle: (index + 1) == _currentPage
                          ? MyStyle.white1_14_400
                          : MyStyle.black1_14_400,
                    ),
                  ),
                ),
              ),
              IconButton(
                icon: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                ),
                onPressed: goToNextPage,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget searchBar() {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Container(
      width: width * 0.74,
      height: height * 0.055,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
      child: TextFormField(
        // textAlign: TextAlign.left,
        keyboardType: TextInputType.multiline,
        cursorColor: MyColor.brown2,

        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20.0),
          ),
          prefixIcon: Icon(
            Icons.search,
            color: MyColor.black1,
          ),
          suffixIcon: Icon(
            Icons.cancel,
            color: MyColor.brown1,
          ),
          hintText: "Search",
          hintStyle: TextStyle(color: MyColor.grey6),
          // filled: true,
          // fillColor: Colors.grey[350],
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: MyColor.grey6, width: 2),
            borderRadius: BorderRadius.circular(20),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: MyColor.grey6, width: 2),
            borderRadius: BorderRadius.circular(20),
          ),
          contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          // isCollapsed: true,
          alignLabelWithHint: true,
        ),
      ),
    );
  }
}
