import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/texts/my_text.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: height * 0.08,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                IconButton(
                  icon: Icon(
                    Icons.close,
                    color: MyColor.black1,
                    size: 35,
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
                SizedBox(
                  width: width * 0.01,
                ),
                searchBar()
              ],
            ),
            SizedBox(
              height: height * 0.01,
            ),
            Container(
              padding: EdgeInsets.only(left: 15, top: 10),
              color: MyColor.grey4,
              height: height * 0.05,
              width: width,
              child: MyText(
                  text: "Recent searches", textStyle: MyStyle.black1_13_600),
            ),
            SizedBox(
              height: height * 0.023,
            ),
            Row(
              children: [
                SizedBox(
                  width: width * 0.05,
                ),
                Icon(
                  Icons.refresh_outlined,
                  size: 30,
                ),
                SizedBox(
                  width: width * 0.05,
                ),
                MyText(text: "Hugendubel.de", textStyle: MyStyle.black1_14_400),
              ],
            ),
            SizedBox(
              height: height * 0.02,
            ),
            Row(
              children: [
                SizedBox(
                  width: width * 0.05,
                ),
                Icon(
                  Icons.refresh_outlined,
                  size: 30,
                ),
                SizedBox(
                  width: width * 0.05,
                ),
                MyText(text: "Cross down", textStyle: MyStyle.black1_14_400),
              ],
            ),
            SizedBox(
              height: height * 0.01,
            ),
            MyText(text: "CLEAR ALL", textStyle: MyStyle.blue1_16_600),
            SizedBox(
              height: height * 0.01,
            ),
            Container(
              padding: EdgeInsets.only(left: 15, top: 10),
              color: MyColor.grey4,
              height: height * 0.05,
              width: width,
              child: MyText(
                  text: "Book Results (3)", textStyle: MyStyle.black1_13_600),
            ),
            SizedBox(
              height: height * 0.01,
            ),
            bookResultCard(),
            bookResultCard(),
            bookResultCard(),
            bookResultCard(),
            bookResultCard(),
            bookResultCard(),
            bookResultCard(),
            SizedBox(
              height: height * 0.01,
            ),
            Container(
              padding: EdgeInsets.only(left: 15, top: 10),
              color: MyColor.grey4,
              height: height * 0.05,
              width: width,
              child: MyText(
                  text: "Author Results (5)", textStyle: MyStyle.black1_13_600),
            )
          ],
        ),
      ),
    );
  }

  Widget bookResultCard() {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              width: width * 0.05,
            ),
            Image.asset(
              'images/book_image.png',
              // Replace with the actual path to the book image
              height: width * 0.13, // Adjust the height as needed
            ),
            SizedBox(
              width: width * 0.05,
            ),
            MyText(text: "Cross Down", textStyle: MyStyle.black1_14_400),
            Spacer(),
            Container(
              padding: EdgeInsets.all(5),
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(100.0),
                  child: Icon(
                    Icons.cloud_download,
                    color: MyColor.brown1,
                  )),
              decoration: BoxDecoration(
                border: Border.all(
                  color: MyColor.brown1,
                  width: 1.0,
                ),
                color: MyColor.white1,
                borderRadius: BorderRadius.circular(100),
              ),
            ),
            SizedBox(
              width: width * 0.04,
            ),
          ],
        ),
        SizedBox(
          height: height * 0.021,
        ),
      ],
    );
  }

  Widget searchBar() {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Container(
      width: width * 0.79,
      height: height * 0.055,
      child: TextFormField(
        // textAlign: TextAlign.left,
        keyboardType: TextInputType.multiline,
        cursorColor: MyColor.brown2,

        decoration: InputDecoration(
          prefixIcon: Icon(
            Icons.search,
            color: MyColor.black1,
          ),
          suffixIcon: Icon(
            Icons.cancel,
            color: MyColor.brown1,
          ),
          hintText: "Hugendubel.de",
          hintStyle: TextStyle(color: MyColor.grey1),
          // filled: true,
          // fillColor: Colors.grey[350],
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: MyColor.grey2, width: 2),
            borderRadius: BorderRadius.circular(7),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: MyColor.grey2, width: 2),
            borderRadius: BorderRadius.circular(7),
          ),
          contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          // isCollapsed: true,
          alignLabelWithHint: true,
        ),
      ),
    );
  }
}
