import 'package:estate_mobile_app/static/views/home/payments/payment_details_page.dart';
import 'package:estate_mobile_app/static/views/home/payments/widgets/payment_method_selector.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_small_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/buttons/my_custom_button.dart';
import '../../../widgets/textfields/my_textfield.dart';
import '../../../widgets/texts/my_text.dart';

class PaymentMethodPage extends StatefulWidget {
  const PaymentMethodPage({super.key});

  @override
  State<PaymentMethodPage> createState() => _PaymentMethodPageState();
}

class _PaymentMethodPageState extends State<PaymentMethodPage> {
  bool isCard = true;
  bool isPayPal = false;
  bool isApplePay = false;

  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: MyColor.white1,
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: MyColor.blue1,
          title: MyText(
            text: 'Payment Methods',
            textStyle: MyStyle.white1_25_800,
          ),
          elevation: 0,
        ),
        body: Stack(
          children: [
            Column(
              children: [
                Expanded(
                  child: Container(
                    height: height * 0.28,
                    color: MyColor.blue1,
                  ),
                ),
                Container(
                  width: width,
                  height: height * 0.52,
                  decoration: BoxDecoration(
                    color: MyColor.white1,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(60.0),
                    ),
                  ),
                ),
                Container(
                  width: width,
                  height: height * 0.20,
                  decoration: BoxDecoration(
                    color: MyColor.grey3,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(60.0),
                      topRight: Radius.circular(60.0),
                    ),
                  ),
                ),
              ],
            ),
            Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: height * 0.04,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Image.asset(
                      "images/payment_method.png",
                      height: height * 0.20,
                      width: width,
                    ),
                  ),
                  SizedBox(height: height * 0.03),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 25.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          MyText(
                              text: "     All Payment methods",
                              textStyle: MyStyle.black1_19_000),
                          SizedBox(height: height * 0.03),
                          PaymentMethodSelector(
                            text: "Credit Card/Debit Card",
                            imagePath: "images/credit_logo.png",
                            isSelected: isCard,
                            onPressed: () {
                              setState(() {
                                isCard = true;
                                isPayPal = false;
                                isApplePay = false;
                              });
                            },
                          ),
                          SizedBox(height: height * 0.01),
                          PaymentMethodSelector(
                            text: "PayPal",
                            imagePath: "images/paypal_logo.png",
                            isSelected: isPayPal,
                            onPressed: () {
                              setState(() {
                                isCard = false;
                                isPayPal = true;
                                isApplePay = false;
                              });
                            },
                          ),
                          SizedBox(height: height * 0.01),
                          PaymentMethodSelector(
                            text: "Apple Pay",
                            imagePath: "images/apple_pay_logo.png",
                            isSelected: isApplePay,
                            onPressed: () {
                              setState(() {
                                isCard = false;
                                isPayPal = false;
                                isApplePay = true;
                              });
                            },
                          ),
                          Spacer(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              iconButton(onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: ((context) =>
                                            PaymentDetailsPage(
                                                isPayPal: isPayPal))));
                              }),
                              Column(
                                children: [
                                  MyText(
                                      text: "\$202.54",
                                      textStyle: MyStyle.black1_30_800),
                                  MyText(
                                      text: "View Details",
                                      textStyle: MyStyle.black1_19_000),
                                ],
                              )
                            ],
                          ),
                          SizedBox(height: height * 0.06),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ));
  }

  Widget iconButton({required VoidCallback onPressed}) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 25, vertical: 6),
        height: height * 0.06,
        width: width * 0.32,
        decoration: BoxDecoration(
          color: MyColor.brown1,
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: Row(
          children: [
            Text(
              "Pay",
              style: MyStyle.white1_17_700,
            ),
            SizedBox(
              width: width * 0.02,
            ),
            Icon(
              Icons.arrow_forward_sharp,
              color: MyColor.white1,
            )
          ],
        ),
      ),
    );
  }
}
