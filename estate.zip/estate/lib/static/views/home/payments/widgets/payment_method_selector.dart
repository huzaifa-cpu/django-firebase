import 'package:flutter/cupertino.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';

class PaymentMethodSelector extends StatefulWidget {
  VoidCallback onPressed;
  String imagePath;
  String text;
  bool isSelected;

  PaymentMethodSelector(
      {super.key,
      required this.onPressed,
      required this.imagePath,
      required this.isSelected,
      required this.text});

  @override
  State<PaymentMethodSelector> createState() => _PaymentMethodSelectorState();
}

class _PaymentMethodSelectorState extends State<PaymentMethodSelector> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: widget.onPressed,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 25, vertical: 6),
        height: height * 0.08,
        width: width,
        decoration: BoxDecoration(
          color: widget.isSelected ? MyColor.grey3 : MyColor.white1,
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: Row(
          children: [
            Image.asset(
              widget.imagePath,
              // height: height * 0.5,
            ),
            SizedBox(
              width: width * 0.04,
            ),
            Text(
              widget.text,
              style: MyStyle.black1_19_000,
            ),
          ],
        ),
      ),
    );
  }
}
