import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_button.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_custom_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../widgets/textfields/my_static_textfield.dart';
import '../../../widgets/textfields/my_textfield.dart';
import '../../../widgets/texts/my_text.dart';

class PaymentDetailsPage extends StatefulWidget {
  bool isPayPal;

  PaymentDetailsPage({super.key, required this.isPayPal});

  @override
  State<PaymentDetailsPage> createState() => _PaymentDetailsPageState();
}

class _PaymentDetailsPageState extends State<PaymentDetailsPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: MyColor.blue1,
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: MyColor.blue1,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: MyColor.white1,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: MyText(
            text: 'Payment Details',
            textStyle: MyStyle.white1_25_800,
          ),
          elevation: 0,
        ),
        body: Stack(
          children: [
            Column(
              children: [
                Expanded(
                  child: Container(
                    height: height * 0.28,
                    color: MyColor.blue1,
                  ),
                ),
                Container(
                  width: width,
                  height: height * 0.72,
                  decoration: BoxDecoration(
                    color: MyColor.white1,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(60)),
                  ),
                ),
              ],
            ),
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: height * 0.04,
                    ),
                    widget.isPayPal
                        ? Container(
                            // padding: EdgeInsets.all(20),
                            width: width,
                            height: height * 0.21,
                            child: Card(
                              elevation: 4.0, // Set the elevation for the card
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                    20.0), // Set the border radius for the card
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(20.0),
                                // Set the same border radius for the clip rectangle
                                child: Image.asset(
                                  "images/paypal.png",
                                  height: height * 0.005,
                                ),
                              ),
                            ),
                          )
                        : Image.asset("images/debit_card.png"),
                    SizedBox(height: height * 0.03),
                    MyText(text: "Card Number", textStyle: MyStyle.black1_19_000),
                    SizedBox(height: height * 0.005),
                    MyTextField(hintText: "1234 7843 1237 1279"),
                    SizedBox(height: height * 0.02),
                    Row(
                      children: [
                        Expanded(
                            flex: 2,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                MyText(
                                    text: "Expiry Date",
                                    textStyle: MyStyle.black1_19_000),
                                SizedBox(height: height * 0.005),
                                MyTextField(hintText: "Usman Farooq"),
                              ],
                            )),
                        SizedBox(
                          width: width * 0.1,
                        ),
                        Expanded(
                            flex: 1,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                MyText(text: "CVV", textStyle: MyStyle.black1_19_000),
                                SizedBox(height: height * 0.005),
                                MyTextField(hintText: "658"),
                              ],
                            )),
                      ],
                    ),
                    SizedBox(height: height * 0.02),
                    MyText(text: "Name", textStyle: MyStyle.black1_19_000),
                    SizedBox(height: height * 0.005),
                    MyTextField(hintText: "Usman Farooq"),
                    SizedBox(height: height * 0.02),
                    Align(
                        alignment: Alignment.topRight,
                        child: MyText(
                            text: "\$202.54", textStyle: MyStyle.black1_30_800)),
                    SizedBox(height: height * 0.03),
                    MyCustomButton(
                      color: MyColor.brown1,
                      onPressed: () {},
                      text: "Pay Now",
                      width: width,
                      height: height * 0.06,
                      textStyle: MyStyle.white1_17_700,
                    )
                  ],
                ),
              ),
            )
          ],
        ));
  }
}
