import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/views/home/calls/voice_call_page.dart';
import 'package:estate_mobile_app/static/views/home/homes/home_page.dart';
import 'package:estate_mobile_app/static/widgets/texts/my_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class VideoCallPage extends StatefulWidget {
  const VideoCallPage({super.key});

  @override
  State<VideoCallPage> createState() => _VideoCallPageState();
}

class _VideoCallPageState extends State<VideoCallPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Container(
            width: width,
            child: Image.asset(
              "images/call_pic.png",
              fit: BoxFit.fill,
            ),
          ),
          Container(
            width: width,
            color: MyColor.black1.withOpacity(0.2),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: height * 0.13,
                ),
                MyText(text: "Dr. Peter", textStyle: MyStyle.white1_30_800),
                SizedBox(
                  height: height * 0.002,
                ),
                MyText(text: "John", textStyle: MyStyle.white1_30_800),
                SizedBox(
                  height: height * 0.02,
                ),
                MyText(text: "Incoming 00.01", textStyle: MyStyle.white1_12_700),
                Spacer(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    callButton(Icons.mic, MyColor.white1, MyColor.black1, (){}),
                    callButton(Icons.call_end, MyColor.red1, MyColor.white1, (){
                      Navigator.pop(context);
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: ((context) => HomePage())));
                    }),
                    callButton(Icons.volume_up_sharp, MyColor.white1, MyColor.black1, (){
                      Navigator.pop(context);
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: ((context) => VoiceCallPage())));
                    }),
                    // SizedBox(
                    //   width: width * 0.2,
                    // ),
                  ],
                ),
                SizedBox(
                  height: height * 0.07,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget callButton(IconData iconData, Color color, Color iconColor, VoidCallback onPressed) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(100),
        ),
        child: ClipRRect(
            borderRadius: BorderRadius.circular(100.0),
            // Set the same border radius for the clip rectangle
            child: Icon(
              iconData,
              size: 35,
              color: iconColor,
            )),
      ),
    );
  }
}
