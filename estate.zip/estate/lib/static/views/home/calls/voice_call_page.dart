// ignore_for_file: prefer_const_constructors

import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_style.dart';
import '../../../widgets/texts/my_text.dart';
import '../homes/home_page.dart';

class VoiceCallPage extends StatefulWidget {
  const VoiceCallPage({super.key});

  @override
  State<VoiceCallPage> createState() => _VoiceCallPageState();
}

class _VoiceCallPageState extends State<VoiceCallPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: MyColor.blue1,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: height * 0.13,
            ),
            MyText(text: "Dr. Peter John", textStyle: MyStyle.white1_30_800),
            SizedBox(
              height: height * 0.002,
            ),
            MyText(text: "Calling", textStyle: MyStyle.white1_17_700),
            SizedBox(
              height: height * 0.04,
            ),
            Container(
              padding: EdgeInsets.all(30),
              decoration: BoxDecoration(
                color: MyColor.blue2,
                borderRadius: BorderRadius.circular(100),
              ),
              child: Card(
                elevation: 4.0, // Set the elevation for the card
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                      100.0), // Set the border radius for the card
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(
                      100.0), // Set the same border radius for the clip rectangle
                  child: Image.asset(
                    "images/coach-pic.png", // Replace with your own image URL
                    fit: BoxFit.cover,
                    height: height * 0.17,
                  ),
                ),
              ),
            ),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                callButtonWithText(Icons.mic, () {}, "Audio"),
                callButtonWithText(Icons.mic, () {}, "Microphone"),
              ],
            ),
            SizedBox(
              height: height * 0.07,
            ),
            callButton(Icons.call_end, MyColor.red1, MyColor.white1, () {
              Navigator.pop(context);
              Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: ((context) => HomePage())));
            }),
            SizedBox(
              height: height * 0.15,
            ),
          ],
        ),
      ),
    );
  }

  Widget callButtonWithText(
      IconData iconData, VoidCallback onPressed, String text) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onPressed,
      child: Column(
        children: [
          Icon(
            iconData,
            size: 35,
            color: MyColor.white1,
          ),
          MyText(text: text, textStyle: MyStyle.white1_17_700)
        ],
      ),
    );
  }

  Widget callButton(
      IconData iconData, Color color, Color iconColor, VoidCallback onPressed) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(100),
        ),
        child: ClipRRect(
            borderRadius: BorderRadius.circular(100.0),
            // Set the same border radius for the clip rectangle
            child: Icon(
              iconData,
              size: 35,
              color: iconColor,
            )),
      ),
    );
  }
}
