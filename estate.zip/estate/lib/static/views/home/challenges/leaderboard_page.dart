import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/texts/my_text.dart';

class LeaderboardPage extends StatefulWidget {
  const LeaderboardPage({super.key});

  @override
  State<LeaderboardPage> createState() => _LeaderboardPageState();
}

class _LeaderboardPageState extends State<LeaderboardPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery
        .of(context)
        .size
        .height;
    var width = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(
      backgroundColor: MyColor.white1,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: MyColor.blue1,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.white1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Leaderboard',
          textStyle: MyStyle.white1_22_800,
        ),
        elevation: 0,
      ),
      body: Column(
        children: [
          ClipPath(
            clipper: MyCustomClipper(),
            child: Container(
              padding: EdgeInsets.only(top: 12),
              height: height * 0.38,
              width: width,
              decoration: BoxDecoration(
                color: MyColor.blue1,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 13),
                    child: positions("2nd", "456000", height * 0.09),
                  ),
                  positions("1st", "55000", height * 0.12),
                  Padding(
                    padding: const EdgeInsets.only(top: 13),
                    child: positions("3rd", "445000", height * 0.09),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  height: height * 0.06,
                  decoration: BoxDecoration(
                    color: MyColor.blue2,
                    borderRadius:
                    BorderRadius.vertical(top: Radius.circular(10)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      MyText(text: "RANK", textStyle: MyStyle.white1_17_700),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: MyText(text: "NAME", textStyle: MyStyle.white1_17_700),
                      ),
                      MyText(
                          text: "HIGHEST SCORE",
                          textStyle: MyStyle.white1_17_700),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(right: 50, left: 25),
                  height: height * 0.09,
                  decoration: BoxDecoration(
                    color: MyColor.grey3,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      MyText(text: "4", textStyle: MyStyle.black1_30_800),
                      MyText(text: "Player", textStyle: MyStyle.black1_17_700),
                      MyText(text: "32000", textStyle: MyStyle.black1_20_800),
                    ],
                  ),
                ), Container(
                  padding: EdgeInsets.only(right: 50, left: 25),
                  height: height * 0.09,
                  decoration: BoxDecoration(
                    color: MyColor.grey2,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      MyText(text: "5", textStyle: MyStyle.blue1_30_800),
                      MyText(text: "Player", textStyle: MyStyle.blue1_17_700),
                      MyText(text: "31000", textStyle: MyStyle.blue1_20_800),
                    ],
                  ),
                ), Container(
                  padding: EdgeInsets.only(right: 50, left: 25),
                  height: height * 0.09,
                  decoration: BoxDecoration(
                    color: MyColor.grey3,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      MyText(text: "6", textStyle: MyStyle.black1_30_800),
                      MyText(text: "Player", textStyle: MyStyle.black1_17_700),
                      MyText(text: "22000", textStyle: MyStyle.black1_20_800),
                    ],
                  ),
                ), Container(
                  padding: EdgeInsets.only(right: 50, left: 25),
                  height: height * 0.09,
                  decoration: BoxDecoration(
                    color: MyColor.grey2,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      MyText(text: "7", textStyle: MyStyle.blue1_30_800),
                      MyText(text: "Player", textStyle: MyStyle.blue1_17_700),
                      MyText(text: "21000", textStyle: MyStyle.blue1_20_800),
                    ],
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget positions(String position, String score, double imageHeight) {
    //HEIGHT-WIDTH
    var height = MediaQuery
        .of(context)
        .size
        .height;
    var width = MediaQuery
        .of(context)
        .size
        .width;
    return Column(
      children: [
        MyText(text: position, textStyle: MyStyle.white1_20_800),
        Container(
          padding: EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: MyColor.blue2,
            borderRadius: BorderRadius.circular(100),
          ),
          child: Card(
            elevation: 4.0, // Set the elevation for the card
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(
                  100.0), // Set the border radius for the card
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(100.0),
              // Set the same border radius for the clip rectangle
              child: Image.asset(
                "images/coach-pic.png",
                // Replace with your own image URL
                fit: BoxFit.cover,
                height: imageHeight,
              ),
            ),
          ),
        ),
        SizedBox(
          height: height * 0.01,
        ),
        MyText(text: "Player", textStyle: MyStyle.white1_17_700),
        MyText(text: "Score", textStyle: MyStyle.white1_17_700),
        MyText(text: score, textStyle: MyStyle.white1_20_800),
      ],
    );
  }
}

class MyCustomClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.moveTo(0, size.height * 0.75);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height * 0.75);
    path.lineTo(size.width, 0);
    path.lineTo(0, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}
