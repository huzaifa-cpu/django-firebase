import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/views/home/challenges/challenge_details_page.dart';
import 'package:estate_mobile_app/static/views/home/challenges/widgets/completion_bar.dart';
import 'package:estate_mobile_app/static/views/home/challenges/widgets/outline_container.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../widgets/buttons/my_custom_button.dart';
import '../../../widgets/texts/my_text.dart';
import 'finance_page.dart';

class ChallengePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.black1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Challenges',
          textStyle: MyStyle.black1_25_800,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(22.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      MyText(
                          text: "Active Challenge", textStyle: MyStyle.black1_22_800),
                      MyText(text: "View All", textStyle: MyStyle.black1_18_000),
                    ],
                  ),
                  SizedBox(
                    height: height * 0.015,
                  ),
                  Card(
                    color: MyColor.cream1,
                    elevation: 4.0, // Set the elevation for the card
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                          15.0), // Set the border radius for the card
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15.0),
                      // Set the same border radius for the clip rectangle
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 15, vertical: 18),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Image.asset(
                              "images/book_icon.png",
                              // Replace with your own image URL
                              fit: BoxFit.cover,
                              height: height * 0.06,
                            ),
                            SizedBox(
                              width: width * 0.045,
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        flex: 2,
                                        child: MyText(
                                            text: "Reading Book",
                                            textStyle: MyStyle.black1_18_000),
                                      ),
                                      Spacer(),
                                      MyText(
                                          text: "3 days left",
                                          textStyle: MyStyle.grey1_14_500),
                                    ],
                                  ),
                                  SizedBox(
                                    height: height * 0.01,
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: CompletionBar(
                                          completion: 0.72,
                                          progressColor: MyColor.blue1,
                                          bgColor: MyColor.grey1,
                                        ),
                                      ),
                                      SizedBox(
                                        width: width * 0.04,
                                      ),
                                      MyText(
                                          text: "72%",
                                          textStyle: MyStyle.black1_15_200),
                                    ],
                                  ),
                                  SizedBox(
                                    height: height * 0.015,
                                  ),
                                  MyCustomButton(
                                      color: MyColor.blue1,
                                      textStyle: MyStyle.white1_12_700,
                                      width: width * 0.32,
                                      height: height * 0.037,
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: ((context) =>
                                                    ChallengeDetailsPage())));
                                      },
                                      text: "Complete Now")
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: height * 0.03,
                  ),
                  MyText(
                      text: "Challenges Completed", textStyle: MyStyle.black1_22_800),
                  SizedBox(
                    height: height * 0.02,
                  ),
                  Row(
                    children: [
                      OutlineContainer(
                          text: "Learning", isNumber: true, number: "12"),
                      SizedBox(
                        width: width * 0.05,
                      ),
                      OutlineContainer(
                          text: "Health", isNumber: true, number: "8"),
                    ],
                  ),
                  SizedBox(
                    height: height * 0.02,
                  ),
                  Row(
                    children: [
                      OutlineContainer(
                          text: "Habbit", isNumber: true, number: "6"),
                      SizedBox(
                        width: width * 0.05,
                      ),
                      OutlineContainer(
                          text: "Dicipline", isNumber: true, number: "2"),
                    ],
                  ),
                ],
              ),
            ),
            Center(
              child:
                  MyText(text: "Browse Challenge", textStyle: MyStyle.black1_22_800),
            ),
            SizedBox(
              height: height * 0.03,
            ),
            SizedBox(
              height: height * 0.15,
              child: GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: ((context) => FinancePage())));
                },
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Image.asset(
                      "images/habit_challenge.png",
                      fit: BoxFit.cover,
                      height: height * 0.15,
                    ),
                    SizedBox(
                      width: width * 0.03,
                    ),
                    Image.asset(
                      "images/habit_challenge.png",
                      fit: BoxFit.cover,
                      height: height * 0.15,
                    ),
                    SizedBox(
                      width: width * 0.03,
                    ),
                    Image.asset(
                      "images/habit_challenge.png",
                      fit: BoxFit.cover,
                      height: height * 0.15,
                    ),
                    SizedBox(
                      width: width * 0.03,
                    ),
                    Image.asset(
                      "images/habit_challenge.png",
                      fit: BoxFit.cover,
                      height: height * 0.15,
                    ),
                    // Add more images as needed
                  ],
                ),
              ),
            ),
            SizedBox(
              height: height * 0.03,
            ),
            Center(
              child: MyCustomButton(
                  color: MyColor.blue1,
                  textStyle: MyStyle.white1_17_700,
                  width: width * 0.5,
                  height: height * 0.055,
                  onPressed: () {
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: ((context) => PaymentMethodPage())));
                  },
                  text: "Browse"),
            )
          ],
        ),
      ),
    );
  }
}
