// ignore_for_file: prefer_const_constructors

import 'package:estate_mobile_app/static/views/home/appointments/widgets/appointment_card.dart';
import 'package:estate_mobile_app/static/views/home/challenges/widgets/finance_card.dart';
import 'package:flutter/material.dart';

// import '../../../../utils/my_color.dart';
// import '../../../../utils/my_style.dart';
// import '../../../../widgets/texts/my_text.dart';
import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/texts/my_text.dart';

class FinancePage extends StatefulWidget {
  const FinancePage({super.key});

  @override
  State<FinancePage> createState() => _FinancePageState();
}

class _FinancePageState extends State<FinancePage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: MyColor.white1,
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.transparent,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: MyColor.black1,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: MyText(
            text: 'Finance',
            textStyle: MyStyle.black1_25_800,
          ),
          elevation: 0,
        ),
        body: FinanceCard());
  }
}
