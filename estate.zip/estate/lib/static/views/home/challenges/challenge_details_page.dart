import 'package:estate_mobile_app/static/views/home/challenges/leaderboard_page.dart';
import 'package:estate_mobile_app/static/views/home/challenges/profile_page.dart';
import 'package:estate_mobile_app/static/views/home/challenges/widgets/completion_bar.dart';
import 'package:estate_mobile_app/static/views/home/challenges/widgets/text_icon_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/buttons/my_custom_button.dart';
import '../../../widgets/buttons/my_custom_rounded_button.dart';
import '../../../widgets/texts/my_text.dart';

class ChallengeDetailsPage extends StatefulWidget {
  const ChallengeDetailsPage({super.key});

  @override
  State<ChallengeDetailsPage> createState() => _ChallengeDetailsPageState();
}

class _ChallengeDetailsPageState extends State<ChallengeDetailsPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: MyColor.white1,
      body: Column(
        children: [
          SizedBox(
            height: height * 0.06,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(
                  Icons.arrow_back,
                  color: MyColor.black1,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              MyText(
                text: 'Challenges',
                textStyle: MyStyle.black1_22_800,
              ),
              IconButton(
                icon: Icon(
                  Icons.notifications_none_sharp,
                  color: MyColor.black1,
                  size: 30,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              )
            ],
          ),
          SizedBox(
            height: height * 0.03,
          ),
          Container(
            width: width,
            // height: height * 0.8,
            decoration: BoxDecoration(
              color: MyColor.grey4,
              borderRadius: BorderRadius.vertical(top: Radius.circular(50)),
            ),
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: height * 0.003,
                  ),
                  Center(
                    child: Container(
                      width: width * 0.3,
                      height: height * 0.01,
                      decoration: BoxDecoration(
                          color: MyColor.grey5,
                          borderRadius: BorderRadius.circular(50)),
                    ),
                  ),
                  SizedBox(
                    height: height * 0.012,
                  ),
                  Center(
                    child: MyText(
                      text: 'Challenge Details',
                      textStyle: MyStyle.black1_20_800,
                    ),
                  ),
                  SizedBox(
                    height: height * 0.012,
                  ),
                  Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(15.0),
                        child: Image.asset(
                          "images/challenge_bg.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 15, vertical: 20),
                        child: Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset(
                                  "images/book_icon.png",
                                  fit: BoxFit.cover,
                                  height: height * 0.06,
                                ),
                                SizedBox(
                                  width: width * 0.045,
                                ),
                                Expanded(
                                  flex: 2,
                                  child: MyText(
                                      text: "Reading Book",
                                      textStyle: MyStyle.white1_17_700),
                                ),
                                Spacer(),
                                MyText(
                                    text: "3 days left",
                                    textStyle: MyStyle.white1_14_400),
                              ],
                            ),
                            SizedBox(
                              height: height * 0.012,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: MyText(
                                      text: "Lessons in Corporate Finance",
                                      textStyle: MyStyle.white1_17_700),
                                ),
                                SizedBox(
                                  width: width * 0.045,
                                ),
                                MyCustomRoundedButton(
                                    color: MyColor.white1,
                                    textStyle: MyStyle.black1_12_700,
                                    width: width * 0.32,
                                    height: height * 0.037,
                                    onPressed: () {
                                      // Navigator.push(
                                      //     context,
                                      //     MaterialPageRoute(
                                      //         builder: ((context) => PaymentMethodPage())));
                                    },
                                    text: "Continue")
                              ],
                            ),
                            SizedBox(
                              height: height * 0.012,
                            ),
                            Row(
                              children: [
                                Expanded(
                                  child: CompletionBar(
                                    completion: 0.72,
                                    progressColor: MyColor.white1,
                                    bgColor: MyColor.grey1,
                                  ),
                                ),
                                SizedBox(
                                  width: width * 0.04,
                                ),
                                MyText(
                                    text: "72%",
                                    textStyle: MyStyle.white1_17_700),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: height * 0.012,
                  ),
                  MyText(
                      text: "You have to do",
                      textStyle: MyStyle.black1_18_700),
                  SizedBox(
                    height: height * 0.015,
                  ),
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(6),
                        width: width * 0.15,
                        // height: height * 0.002,
                        decoration: BoxDecoration(
                            color: MyColor.blue4,
                            borderRadius: BorderRadius.circular(15)),
                        child: Image.asset("images/chapter.png"),
                      ),
                      SizedBox(
                        width: width * 0.04,
                      ),
                      Row(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  MyText(
                                      text: "Read Chapter 4",
                                      textStyle: MyStyle.black1_18_700),
                                  SizedBox(
                                    width: width * 0.2,
                                  ),
                                  MyText(
                                      text: "4 of 9",
                                      textStyle: MyStyle.grey1_15_000),
                                ],
                              ),
                              MyText(
                                  text: "Keep going, you can do it!",
                                  textStyle: MyStyle.grey1_15_000),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: height * 0.02,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: ((context) => LeaderboardPage())));
                    },
                    child: Container(
                      padding: EdgeInsets.all(15),
                      width: width,
                      height: height * 0.06,
                      decoration: BoxDecoration(
                          color: MyColor.grey5,
                          borderRadius: BorderRadius.circular(10)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          MyText(
                              text: "Leaderboard",
                              textStyle: MyStyle.black1_16_600),
                          Icon(
                            Icons.arrow_forward_ios_rounded,
                            color: MyColor.blue1,
                            size: 16,
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: height * 0.014,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      MyText(
                          text: "Group members",
                          textStyle: MyStyle.black1_18_700),
                      MyText(
                          text: "View all", textStyle: MyStyle.grey1_16_400),
                    ],
                  ),
                  SizedBox(
                    height: height * 0.01,
                  ),
                  Row(
                    children: [
                      imageWithText("Jamal"),
                      SizedBox(
                        width: width * 0.025,
                      ),
                      imageWithText("Alek"),
                      SizedBox(
                        width: width * 0.025,
                      ),
                      imageWithText("Clair"),
                      SizedBox(
                        width: width * 0.025,
                      ),
                      imageWithText("Dustin"),
                    ],
                  ),
                  SizedBox(
                    height: height * 0.015,
                  ),
                  Container(
                    padding: EdgeInsets.all(15),
                    width: width,
                    height: height * 0.1,
                    decoration: BoxDecoration(
                        color: MyColor.grey5,
                        borderRadius: BorderRadius.circular(14)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                MyText(
                                    text: "Jamal ",
                                    textStyle: MyStyle.black1_16_600),
                                MyText(
                                    text: "is almost done.",
                                    textStyle: MyStyle.grey6_17_400),
                              ],
                            ),
                            MyText(
                                text: "You need to hurry!",
                                textStyle: MyStyle.grey6_17_400),
                          ],
                        ),
                        Container(
                          width: width * 0.2,
                          // height: 100,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              CircularProgressIndicator(
                                value: 85 / 100,
                                strokeWidth: 3,
                                backgroundColor: Colors.grey[300],
                                valueColor: AlwaysStoppedAnimation<Color>(
                                    MyColor.blue1),
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 5),
                                child: MyText(
                                    text: "85% ",
                                    textStyle: MyStyle.black1_16_600),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: height * 0.045,
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget imageWithText(String text) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context, MaterialPageRoute(builder: ((context) => ProfilePage())));
      },
      child: Column(
        children: [
          Card(
            elevation: 4.0, // Set the elevation for the card
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(
                  100.0), // Set the border radius for the card
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(100.0),
              // Set the same border radius for the clip rectangle
              child: Image.asset(
                "images/coach-pic.png",
                // Replace with your own image URL
                fit: BoxFit.cover,
                height: height * 0.06,
              ),
            ),
          ),
          SizedBox(
            height: height * 0.01,
          ),
          MyText(text: text, textStyle: MyStyle.grey6_15_400),
        ],
      ),
    );
  }
}
