// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_key_in_widget_constructors
import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/views/home/challenges/widgets/outline_container.dart';
import 'package:estate_mobile_app/static/views/home/challenges/widgets/text_icon_widget.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../widgets/texts/my_text.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Profile',
          textStyle: MyStyle.black1_25_800,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: height * 0.02),
            Stack(
              children: [
                Container(
                  height: height * 0.2,
                  color: MyColor.blue1,
                ),
                Center(
                  child: Column(
                    children: [
                      SizedBox(height: height * 0.06),
                      Image.asset('images/profile.png'),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: height * 0.03),
            Center(
              child: MyText(
                text: "JAMAL",
                textStyle: MyStyle.black1_25_800,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 25),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                      text: "Current Challenges", textStyle: MyStyle.black1_20_800),
                  SizedBox(height: height * 0.015),
                  Row(
                    children: [
                      OutlineContainer(
                          text: "Learning", isNumber: false, number: "12"),
                      SizedBox(
                        width: width * 0.05,
                      ),
                      OutlineContainer(
                          text: "Health", isNumber: false, number: "12"),
                      SizedBox(
                        width: width * 0.05,
                      ),
                      OutlineContainer(
                          text: "Finance", isNumber: false, number: "12"),
                    ],
                  ),
                  SizedBox(height: height * 0.03),
                  MyText(
                      text: "Challenges Completed", textStyle: MyStyle.black1_20_800),
                  SizedBox(height: height * 0.015),
                  Row(
                    children: [
                      OutlineContainer(
                          text: "Learning", isNumber: true, number: "12"),
                      SizedBox(
                        width: width * 0.05,
                      ),
                      OutlineContainer(
                          text: "Health", isNumber: true, number: "8"),
                    ],
                  ),
                  SizedBox(
                    height: height * 0.015,
                  ),
                  Row(
                    children: [
                      OutlineContainer(
                          text: "Habbit", isNumber: true, number: "6"),
                      SizedBox(
                        width: width * 0.05,
                      ),
                      OutlineContainer(
                          text: "Dicipline", isNumber: true, number: "2"),
                    ],
                  ),
                  SizedBox(height: height * 0.06),
                  TextIconWidget(text: "Chat Now", iconData: Icons.chat, onPressed: (){},)
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
