import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/widgets/texts/my_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';

class OutlineContainer extends StatefulWidget {
  String text;
  bool isNumber;
  String number;

  OutlineContainer(
      {super.key,
      required this.text,
      required this.isNumber,
      required this.number});

  @override
  State<OutlineContainer> createState() => _OutlineContainerState();
}

class _OutlineContainerState extends State<OutlineContainer> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 13, vertical: 10),
        decoration: BoxDecoration(
          border: Border.all(
            color: MyColor.grey1,
            width: 1.0,
          ),
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        // height: height * 0.12,
        child: Row(
          children: [
            MyText(text: widget.text, textStyle: MyStyle.grey1_15_000),
            widget.isNumber
                ? Row(
                  children: [
                    SizedBox(
                      width: width * 0.03,
                    ),
                    MyText(text: widget.number, textStyle: MyStyle.black1_16_600),
                  ],
                )
                : Container()
          ],
        ));
  }
}
