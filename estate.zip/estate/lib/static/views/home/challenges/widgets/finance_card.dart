import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// import '../../../../utils/my_color.dart';
// import '../../../../utils/my_style.dart';
// import '../../../../widgets/texts/my_text.dart';
import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';

class FinanceCard extends StatefulWidget {
  @override
  State<FinanceCard> createState() => _FinanceCardState();
}

class _FinanceCardState extends State<FinanceCard> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            selectedBook(),
            unselectedBook(),
            unselectedBook(),
            unselectedBook(),
            unselectedBook(),
            unselectedBook(),
            unselectedBook(),
            unselectedBook(),
            unselectedBook(),
          ],
        ),
      ),
    );
  }

  Widget selectedBook() {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return SizedBox(
      width: width,
      height: height * 0.11,
      child: Card(
        color: MyColor.grey3,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: width * 0.01,
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Container(
                width: width * 0.013,
                color: MyColor.blue1,
                height: height * 0.15,
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: height * 0.01,
                ),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image.asset(
                        "images/finance_image.png",
                        // Replace with your own image URL
                        fit: BoxFit.cover,
                        height: height * 0.06,
                      ),
                    ),
                    SizedBox(
                      width: width * 0.03,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        MyText(
                            text: "Debit Reduction",
                            textStyle: MyStyle.black1_16_600),
                        SizedBox(
                          height: height * 0.001,
                        ),
                      ],
                    ),
                    SizedBox(
                      width: width * 0.2,
                    ),
                    Image.asset('images/play_image.png')
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget unselectedBook() {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return SizedBox(
      width: width,
      height: height * 0.11,
      child: Card(
        color: MyColor.grey3,
        child: Stack(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: width * 0.03,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: height * 0.01,
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset(
                            "images/finance_image.png",
                            // Replace with your own image URL
                            fit: BoxFit.cover,
                            height: height * 0.06,
                          ),
                        ),
                        SizedBox(
                          width: width * 0.05,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            MyText(
                                text: "Cross Down",
                                textStyle: MyStyle.grey1_16_400),
                            SizedBox(
                              height: height * 0.001,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            Container(
              color: MyColor.grey3.withOpacity(0.4),
            )
          ],
        ),
      ),
    );
  }
}
