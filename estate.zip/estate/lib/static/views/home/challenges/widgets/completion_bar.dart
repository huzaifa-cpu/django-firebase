import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:flutter/material.dart';

class CompletionBar extends StatelessWidget {
  final double completion; // Completion value between 0 and 1
  final Color progressColor; // Completion value between 0 and 1
  final Color bgColor; // Completion value between 0 and 1

  CompletionBar(
      {required this.completion,
      required this.progressColor,
      required this.bgColor});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8.0),
      child: LinearProgressIndicator(
        minHeight: 6,
        value: completion, // Set the completion value
        backgroundColor: bgColor, // Customize the background color
        valueColor: AlwaysStoppedAnimation<Color>(
            progressColor), // Customize the progress color
      ),
    );
  }
}
