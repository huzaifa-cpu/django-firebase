import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/widgets/texts/my_text.dart';
import 'package:flutter/cupertino.dart';

import '../../../../utils/my_color.dart';

class TextIconWidget extends StatefulWidget {
  IconData iconData;
  String text;
  VoidCallback onPressed;

  TextIconWidget(
      {super.key,
      required this.text,
      required this.iconData,
      required this.onPressed});

  @override
  State<TextIconWidget> createState() => _TextIconWidgetState();
}

class _TextIconWidgetState extends State<TextIconWidget> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: widget.onPressed,
      child: Container(
        padding: EdgeInsets.all(15),
        width: width,
        height: height * 0.07,
        decoration: BoxDecoration(
            color: MyColor.grey7, borderRadius: BorderRadius.circular(10)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            MyText(text: widget.text, textStyle: MyStyle.black1_16_600),
            Icon(
              widget.iconData,
              color: MyColor.blue1,
            )
          ],
        ),
      ),
    );
  }
}
