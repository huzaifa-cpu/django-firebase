import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';

class NotificationCard extends StatefulWidget {
  const NotificationCard({super.key});

  @override
  State<NotificationCard> createState() => _NotificationCardState();
}

class _NotificationCardState extends State<NotificationCard> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return ListView.builder(
      itemCount: 5,
      itemBuilder: (BuildContext context, int index) {
        return Container(
          margin: EdgeInsets.symmetric(vertical: 5),
          width: width,
          padding: EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: MyColor.grey7,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: height * 0.01,
                  ),
                  MyText(text: "21 minutes ago", textStyle: MyStyle.grey1_14_500),
                  SizedBox(
                    height: height * 0.001,
                  ),
                  // RichText(text: TextSpan(text: 'Note that when you insert multiple rows and use the LAST_INSERT_ID() function to get the last inserted id of an AUTO_INCREMENT column'))
                  MyText(text: "Financial Advisor", textStyle: MyStyle.black1_16_600),
                ],
              ),
              Spacer(),
              Container(
                height: height * 0.09,
                decoration: BoxDecoration(
                  color: MyColor.cream1,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(
                      6.0), // Set the same border radius for the clip rectangle
                  child: Image.asset(
                    "images/ebook.png", // Replace with your own image URL
                    fit: BoxFit.cover,
                    height: height * 0.03,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
