import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';

class CallCard extends StatefulWidget {
  const CallCard({super.key});

  @override
  State<CallCard> createState() => _CallCardState();
}

class _CallCardState extends State<CallCard> {
  bool isVideoCall = false;
  bool isVoiceCall = true;

  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Container(
      width: width,
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: MyColor.grey3,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                  decoration: BoxDecoration(
                    color: MyColor.white1,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(100.0),
                      // Set the same border radius for the clip rectangle
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.calendar_today_outlined,
                          size: height * 0.025,
                        ),
                      ))),
              SizedBox(
                width: width * 0.05,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(text: "Date & Time", textStyle: MyStyle.black1_11_500),
                  SizedBox(
                    height: height * 0.005,
                  ),
                  MyText(text: "Monday 20 Jan 2023", textStyle: MyStyle.grey1_11_500),
                  SizedBox(
                    height: height * 0.005,
                  ),
                  MyText(text: "08:00 AM", textStyle: MyStyle.grey1_11_500),
                ],
              ),
            ],
          ),
          SizedBox(
            height: height * 0.01,
          ),
          Divider(),
          SizedBox(
            height: height * 0.01,
          ),
          Row(
            children: [
              Container(
                  decoration: BoxDecoration(
                    color: MyColor.green1,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(100.0),
                      // Set the same border radius for the clip rectangle
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.video_camera_back,
                          size: height * 0.025,
                          color: MyColor.white1,
                        ),
                      ))),
              SizedBox(
                width: width * 0.05,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(text: "Appointment Type", textStyle: MyStyle.black1_11_500),
                  SizedBox(
                    height: height * 0.02,
                  ),
                  Row(
                    children: [
                      buttonSelector(
                          isVideoCall, "Voice Call", true, Icons.call, context,
                          () {
                        setState(() {
                          isVideoCall = false;
                          isVoiceCall = true;
                        });
                      }),
                      SizedBox(
                        width: width * 0.05,
                      ),
                      buttonSelector(isVoiceCall, "Video Call", true,
                          Icons.video_camera_back, context, () {
                        setState(() {
                          isVideoCall = true;
                          isVoiceCall = false;
                        });
                      }),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget buttonSelector(bool isVideo, String name, bool isWithIcon,
      IconData iconData, BuildContext context, VoidCallback onPressed) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 3),
        decoration: BoxDecoration(
          color: isVideo ? MyColor.grey3 : MyColor.grey2,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          children: [
            Icon(
              iconData,
              size: height * 0.025,
            ),
            SizedBox(
              width: width * 0.02,
            ),
            MyText(text: name, textStyle: MyStyle.black1_11_500)
          ],
        ),
      ),
    );
  }
}
