import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';

class AppointmentCard extends StatefulWidget {
  const AppointmentCard({super.key});

  @override
  State<AppointmentCard> createState() => _AppointmentCardState();
}

class _AppointmentCardState extends State<AppointmentCard> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return ListView.builder(
      itemCount: 11,
      itemBuilder: (BuildContext context, int index) {
        return SizedBox(
          width: width,
          height: height * 0.11,
          child: Card(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: width * 0.01,
                ),
                Container(
                  width: width * 0.013,
                  color: MyColor.blue1,
                  height: height * 0.15,
                ),
                SizedBox(
                  width: width * 0.04,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: height * 0.01,
                    ),
                    Row(
                      children: [
                        Card(
                          elevation: 4.0, // Set the elevation for the card
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                                100.0), // Set the border radius for the card
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(
                                100.0), // Set the same border radius for the clip rectangle
                            child: Image.asset(
                              "images/coach-pic.png", // Replace with your own image URL
                              fit: BoxFit.cover,
                              height: height * 0.06,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: width * 0.03,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            MyText(
                                text: "Mark Johnson",
                                textStyle: MyStyle.black1_16_600),
                            SizedBox(
                              height: height * 0.001,
                            ),
                            MyText(
                                text: "Financial Advisor",
                                textStyle: MyStyle.grey1_14_500),
                          ],
                        ),
                        SizedBox(
                          width: width * 0.2,
                        ),
                        IconButton(
                          icon: Icon(
                            Icons.more_vert,
                            size: height * 0.026,
                          ),
                          onPressed: () {},
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
