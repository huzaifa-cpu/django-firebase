import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';
import '../../calls/video_call_page.dart';

class WaitingRoomCard extends StatefulWidget {
  const WaitingRoomCard({super.key});

  @override
  State<WaitingRoomCard> createState() => _WaitingRoomCardState();
}

class _WaitingRoomCardState extends State<WaitingRoomCard> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Container(
      width: width,
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: MyColor.grey3,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                  decoration: BoxDecoration(
                    color: MyColor.white1,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(100.0),
                      // Set the same border radius for the clip rectangle
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.calendar_today_outlined,
                          size: height * 0.025,
                        ),
                      ))),
              SizedBox(
                width: width * 0.05,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(text: "Date & Time", textStyle: MyStyle.black1_11_500),
                  SizedBox(
                    height: height * 0.005,
                  ),
                  MyText(text: "Monday 20 Jan 2023", textStyle: MyStyle.grey1_11_500),
                  SizedBox(
                    height: height * 0.005,
                  ),
                  MyText(text: "08:00 AM", textStyle: MyStyle.grey1_11_500),
                ],
              ),
            ],
          ),
          SizedBox(
            height: height * 0.01,
          ),
          Divider(),
          SizedBox(
            height: height * 0.01,
          ),
          Row(
            children: [
              Container(
                  decoration: BoxDecoration(
                    color: MyColor.green1,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(100.0),
                      // Set the same border radius for the clip rectangle
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.video_camera_back,
                          size: height * 0.025,
                          color: MyColor.white1,
                        ),
                      ))),
              SizedBox(
                width: width * 0.05,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(text: "Appointment Type", textStyle: MyStyle.black1_11_500),
                  SizedBox(
                    height: height * 0.005,
                  ),
                  MyText(text: "Video Call", textStyle: MyStyle.grey1_11_500),
                  SizedBox(
                    height: height * 0.005,
                  ),
                  waitingRoomButton(context, "Enter Waiting room")
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget waitingRoomButton(BuildContext context, String name) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: () {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: ((context) => VideoCallPage())));
      },
      child: Container(
        width: width * 0.5,
        height: height * 0.03,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 3),
        decoration: BoxDecoration(
          color: MyColor.blue3,
          borderRadius: BorderRadius.circular(2),
        ),
        child: Center(child: MyText(text: name, textStyle: MyStyle.white1_11_200)),
      ),
    );
  }
}
