import 'package:estate_mobile_app/static/views/home/appointments/widgets/call_card.dart';
import 'package:estate_mobile_app/static/views/home/payments/payment_method_page.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_button.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_small_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/buttons/my_custom_button.dart';
import '../../../widgets/texts/my_text.dart';
import '../notifications/widgets/notification_card.dart';

class AppointmentDetailsPage extends StatefulWidget {
  const AppointmentDetailsPage({super.key});

  @override
  State<AppointmentDetailsPage> createState() => _AppointmentDetailsPageState();
}

class _AppointmentDetailsPageState extends State<AppointmentDetailsPage> {
  bool is30Mins = true;
  bool is1Hour = false;

  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: MyColor.white1,
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.transparent,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: MyColor.black1,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: MyText(
            text: 'Appointment Details',
            textStyle: MyStyle.black1_25_800,
          ),
          elevation: 0,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: height * 0.00,
                ),
                MyText(text: "Booking info", textStyle: MyStyle.black1_16_600),
                SizedBox(
                  height: height * 0.015,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: width * 0.01,
                    ),
                    Container(
                      width: width * 0.013,
                      color: MyColor.blue1,
                      height: height * 0.05,
                    ),
                    SizedBox(
                      width: width * 0.03,
                    ),
                    MyText(
                        text: "Book an appointment with your financial coach",
                        textStyle: MyStyle.black1_11_500),
                  ],
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                const CallCard(),
                SizedBox(
                  height: height * 0.03,
                ),
                MyText(text: "Duration", textStyle: MyStyle.black1_16_600),
                SizedBox(
                  height: height * 0.01,
                ),
                Row(
                  children: [
                    buttonSelector(
                        name: "30 minutes",
                        context: context,
                        isSelected: is30Mins,
                        onPressed: () {
                          setState(() {
                            is30Mins = true;
                            is1Hour = false;
                          });
                        }),
                    SizedBox(
                      width: width * 0.05,
                    ),
                    buttonSelector(
                        name: "1 Hour",
                        context: context,
                        isSelected: is1Hour,
                        onPressed: () {
                          setState(() {
                            is30Mins = false;
                            is1Hour = true;
                          });
                        }),
                  ],
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                MyText(text: "Coach Info", textStyle: MyStyle.black1_16_600),
                SizedBox(
                  height: height * 0.01,
                ),
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: height * 0.002,
                        ),
                        Card(
                          elevation: 4.0, // Set the elevation for the card
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                                100.0), // Set the border radius for the card
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100.0),
                            // Set the same border radius for the clip rectangle
                            child: Image.asset(
                              "images/coach-pic.png",
                              // Replace with your own image URL
                              fit: BoxFit.cover,
                              height: height * 0.05,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: width * 0.02,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: height * 0.002,
                        ),
                        MyText(
                            text: "Mark Johnson", textStyle: MyStyle.black1_11_500),
                        SizedBox(
                          height: height * 0.001,
                        ),
                        MyText(
                            text: "Financial Advisor",
                            textStyle: MyStyle.grey1_11_500),
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                MyText(text: "Payment Info", textStyle: MyStyle.black1_16_600),
                SizedBox(
                  height: height * 0.03,
                ),
                Row(
                  children: [
                    MyText(text: "Total Price", textStyle: MyStyle.black1_15_200),
                    Spacer(),
                    MyText(text: "\$200", textStyle: MyStyle.black1_15_200),
                  ],
                ),
                SizedBox(
                  height: height * 0.01,
                ),
                Row(
                  children: [
                    MyText(text: "Tax", textStyle: MyStyle.black1_15_200),
                    Spacer(),
                    MyText(text: "\$2.54", textStyle: MyStyle.black1_15_200),
                  ],
                ),
                SizedBox(
                  height: height * 0.01,
                ),
                Row(
                  children: [
                    MyText(text: "Payment Total", textStyle: MyStyle.black1_16_600),
                    Spacer(),
                    MyText(text: "\$202.54", textStyle: MyStyle.black1_16_600),
                  ],
                ),
                SizedBox(
                  height: height * 0.02,
                ),
                Center(
                    child: MyCustomButton(
                      color: MyColor.brown1,
                        textStyle: MyStyle.white1_12_700,
                        width: width * 0.5,
                        height: height * 0.037,
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: ((context) => PaymentMethodPage())));
                        },
                        text: "Book Now")),
              ],
            ),
          ),
        ));
  }

  Widget buttonSelector(
      {required String name,
      required BuildContext context,
      required bool isSelected,
      required VoidCallback onPressed}) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onPressed,
      child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? MyColor.grey2 : MyColor.grey3,
            borderRadius: BorderRadius.circular(6),
          ),
          child: MyText(text: name, textStyle: MyStyle.black1_11_500)),
    );
  }
}
