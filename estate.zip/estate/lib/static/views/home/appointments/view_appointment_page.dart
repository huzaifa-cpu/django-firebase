import 'package:estate_mobile_app/static/views/home/appointments/widgets/waiting_room_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/buttons/my_custom_button.dart';
import '../../../widgets/texts/my_text.dart';

class ViewAppointmentPage extends StatefulWidget {
  const ViewAppointmentPage({super.key});

  @override
  State<ViewAppointmentPage> createState() => _ViewAppointmentPageState();
}

class _ViewAppointmentPageState extends State<ViewAppointmentPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: MyColor.white1,
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.transparent,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: MyColor.black1,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: MyText(
            text: 'Appointment Details',
            textStyle: MyStyle.black1_25_800,
          ),
          elevation: 0,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: height * 0.00,
                ),
                MyText(text: "Appointment info", textStyle: MyStyle.black1_16_600),
                SizedBox(
                  height: height * 0.015,
                ),
                MyText(text: "Coach Info", textStyle: MyStyle.black1_16_600),
                SizedBox(
                  height: height * 0.01,
                ),
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: height * 0.002,
                        ),
                        Card(
                          elevation: 4.0, // Set the elevation for the card
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                                100.0), // Set the border radius for the card
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100.0),
                            // Set the same border radius for the clip rectangle
                            child: Image.asset(
                              "images/coach-pic.png",
                              // Replace with your own image URL
                              fit: BoxFit.cover,
                              height: height * 0.05,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: width * 0.02,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: height * 0.002,
                        ),
                        MyText(
                            text: "Mark Johnson", textStyle: MyStyle.black1_11_500),
                        SizedBox(
                          height: height * 0.001,
                        ),
                        MyText(
                            text: "Financial Advisor",
                            textStyle: MyStyle.grey1_11_500),
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                MyText(text: "Duration", textStyle: MyStyle.black1_16_600),
                SizedBox(
                  height: height * 0.01,
                ),
                buttonSelector(
                    name: "1 hour",
                    context: context,
                    isSelected: false,
                    onPressed: () {
                      setState(() {});
                    }),
                SizedBox(
                  height: height * 0.02,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: width * 0.01,
                    ),
                    Container(
                      width: width * 0.013,
                      color: MyColor.blue3,
                      height: height * 0.05,
                    ),
                    SizedBox(
                      width: width * 0.03,
                    ),
                    MyText(
                        text: "Tap Enter Waiting room no earlier to enter",
                        textStyle: MyStyle.black1_11_500),
                  ],
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                const WaitingRoomCard(),
                SizedBox(
                  height: height * 0.03,
                ),
              ],
            ),
          ),
        ));
  }

  Widget buttonSelector(
      {required String name,
      required BuildContext context,
      required bool isSelected,
      required VoidCallback onPressed}) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onPressed,
      child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? MyColor.grey2 : MyColor.grey3,
            borderRadius: BorderRadius.circular(6),
          ),
          child: MyText(text: name, textStyle: MyStyle.black1_11_500)),
    );
  }
}
