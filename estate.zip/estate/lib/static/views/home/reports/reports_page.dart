// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_key_in_widget_constructors
import 'package:estate_mobile_app/static/views/home/reports/widgets/chart_dummy_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/texts/my_text.dart';
import 'package:flutter_charts/flutter_charts.dart';
import 'package:intl/intl.dart';

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  bool daily = true;
  bool weekly = false;
  bool monthly = false;

  late TooltipBehavior _tooltipBehavior1;
  late TooltipBehavior _tooltipBehavior2;

  @override
  void initState() {
    super.initState();
    _tooltipBehavior1 = TooltipBehavior(enable: true);
    _tooltipBehavior2 = TooltipBehavior(enable: true);
  }

  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: MyColor.white1,
      appBar: AppBar(
        title: MyText(
          text: 'Reports',
          textStyle: MyStyle.black1_25_800,
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Column(
                children: [
                  SizedBox(
                    height: height * 0.025,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          MyText(
                              text: "Challenges",
                              textStyle: MyStyle.black1_19_000),
                          SizedBox(
                            height: height * 0.015,
                          ),
                          Row(
                            children: [
                              MyText(
                                  text: "28", textStyle: MyStyle.black1_25_800),
                              SizedBox(
                                width: width * 0.04,
                              ),
                              MyText(
                                  text: "Completed",
                                  textStyle: MyStyle.grey6_19_400),
                            ],
                          )
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          MyText(
                              text: "Time", textStyle: MyStyle.black1_19_000),
                          SizedBox(
                            height: height * 0.015,
                          ),
                          Row(
                            children: [
                              MyText(
                                  text: "132",
                                  textStyle: MyStyle.black1_25_800),
                              SizedBox(
                                width: width * 0.04,
                              ),
                              MyText(
                                  text: "Hours",
                                  textStyle: MyStyle.grey6_19_400),
                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: height * 0.04,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Tabs(
                      daily: daily,
                      monthly: monthly,
                      weekly: weekly,
                      weeklyPressed: () {
                        setState(() {
                          daily = false;
                          weekly = true;
                          monthly = false;
                        });
                      },
                      monthlyPressed: () {
                        setState(() {
                          daily = false;
                          weekly = false;
                          monthly = true;
                        });
                      },
                      dailyPressed: () {
                        setState(() {
                          daily = true;
                          weekly = false;
                          monthly = false;
                        });
                      },
                    ),
                  ),
                  SizedBox(
                    height: height * 0.035,
                  ),
                ],
              ),
            ),
            Container(
              height: height * 0.3,
              color: MyColor.cream2,
              child: SfCartesianChart(
                primaryXAxis: CategoryAxis(),
                // title: ChartTitle(text: "Line Chart"),
                tooltipBehavior: _tooltipBehavior1,
                primaryYAxis: NumericAxis(isVisible: false),
                series: <LineSeries<ChartData, String>>[
                  LineSeries<ChartData, String>(
                    dataSource: [
                      ChartData('M', 21),
                      ChartData('T', 29),
                      ChartData('W', 25),
                      ChartData('T', 10),
                      ChartData('F', 20),
                      ChartData('S', 40),
                      ChartData('S', 46),
                    ],
                    xValueMapper: (ChartData sales, _) => sales.day,
                    yValueMapper: (ChartData sales, _) => sales.value,
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: height * 0.04,
                  ),
                  MyText(text: "Challenges", textStyle: MyStyle.black1_18_700),
                  SizedBox(
                    height: height * 0.025,
                  ),
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(6),
                        width: width * 0.15,
                        // height: height * 0.002,
                        decoration: BoxDecoration(
                            color: MyColor.blue4,
                            borderRadius: BorderRadius.circular(15)),
                        child: Image.asset("images/bulb.png"),
                      ),
                      SizedBox(
                        width: width * 0.04,
                      ),
                      Row(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              MyText(
                                  text: "Finance",
                                  textStyle: MyStyle.black1_18_700),
                              MyText(
                                  text: "12 of 14 challenges",
                                  textStyle: MyStyle.grey1_15_000),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: height * 0.04,
                  ),
                  Container(
                    padding: EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: MyColor.grey4,
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.front_hand_sharp,
                          color: MyColor.yellow1,
                          size: 22,
                        ),
                        Icon(
                          Icons.back_hand_sharp,
                          color: MyColor.yellow1,
                          size: 22,
                        ),
                        SizedBox(
                          width: width * 0.04,
                        ),
                        MyText(
                            text: "Absolutely Outstanding!",
                            textStyle: MyStyle.black1_16_000),
                        Spacer(),
                        Icon(
                          Icons.close,
                          color: MyColor.black1,
                          size: 25,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: height * 0.025,
                  ),
                  SizedBox(
                    height: height * 0.025,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ChartData {
  final String day;
  final double value;

  ChartData(this.day, this.value);
}

//-----------------------------------------------------------

class Tabs extends StatefulWidget {
  bool daily;
  bool weekly;
  bool monthly;
  VoidCallback dailyPressed;
  VoidCallback weeklyPressed;
  VoidCallback monthlyPressed;

  Tabs({
    super.key,
    required this.daily,
    required this.monthly,
    required this.weekly,
    required this.weeklyPressed,
    required this.monthlyPressed,
    required this.dailyPressed,
  });

  @override
  State<Tabs> createState() => _TabsState();
}

class _TabsState extends State<Tabs> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 3),
      decoration: BoxDecoration(
        color: MyColor.grey3,
        borderRadius: BorderRadius.circular(100.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: widget.dailyPressed,
            child: Container(
              padding: widget.daily
                  ? const EdgeInsets.symmetric(vertical: 6.0, horizontal: 12)
                  : const EdgeInsets.symmetric(vertical: 6.0, horizontal: 5),
              decoration: BoxDecoration(
                color: widget.daily ? MyColor.white1 : MyColor.grey3,
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: MyText(
                  text: "Daily",
                  textStyle: widget.daily
                      ? MyStyle.black1_16_600
                      : MyStyle.grey6_17_400),
            ),
          ),
          GestureDetector(
            onTap: widget.weeklyPressed,
            child: Container(
              padding: widget.weekly
                  ? const EdgeInsets.symmetric(vertical: 6.0, horizontal: 12)
                  : const EdgeInsets.symmetric(vertical: 6.0, horizontal: 5),
              decoration: BoxDecoration(
                color: widget.weekly ? MyColor.white1 : MyColor.grey3,
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: MyText(
                  text: "Weekly",
                  textStyle: widget.weekly
                      ? MyStyle.black1_16_600
                      : MyStyle.grey6_17_400),
            ),
          ),
          GestureDetector(
            onTap: widget.monthlyPressed,
            child: Container(
              padding: widget.monthly
                  ? const EdgeInsets.symmetric(vertical: 6.0, horizontal: 12)
                  : const EdgeInsets.symmetric(vertical: 6.0, horizontal: 5),
              decoration: BoxDecoration(
                color: widget.monthly ? MyColor.white1 : MyColor.grey3,
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: MyText(
                  text: "Monthly",
                  textStyle: widget.monthly
                      ? MyStyle.black1_16_600
                      : MyStyle.grey6_17_400),
            ),
          ),
        ],
      ),
    );
  }
}
//----------------------------------------------------------------
