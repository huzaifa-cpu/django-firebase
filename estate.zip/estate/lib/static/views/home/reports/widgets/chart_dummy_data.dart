class LinearSales {
  final int day;
  final int sales;

  LinearSales(this.day, this.sales);
}

List<LinearSales> dummyData = [
  LinearSales(0, 10), // Monday
  LinearSales(1, 20), // Tuesday
  LinearSales(2, 15), // Wednesday
  LinearSales(3, 25), // Thursday
  LinearSales(4, 18), // Friday
  LinearSales(5, 30), // Saturday
  LinearSales(6, 22), // Sunday
];


