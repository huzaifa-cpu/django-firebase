import 'package:estate_mobile_app/main.dart';

import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/utils/my_style.dart';
import 'package:estate_mobile_app/static/views/home/appointments/appointments_page.dart';
import 'package:estate_mobile_app/static/views/home/books/books_page.dart';

import 'package:estate_mobile_app/static/views/home/chats/chat_page.dart';
import 'package:estate_mobile_app/static/views/home/notifications/notification_page.dart';
import 'package:estate_mobile_app/static/views/home/homes/widgets/my_appointment_card.dart';
import 'package:estate_mobile_app/static/views/home/more/more_page.dart';
import 'package:estate_mobile_app/static/views/home/reports/reports_page.dart';
import 'package:estate_mobile_app/static/views/home/homes/widgets/ebook_card.dart';
import 'package:estate_mobile_app/static/views/home/homes/widgets/fin_coach_card.dart';
import 'package:flutter/material.dart';

import '../../../widgets/icons/bottom_icon.dart';
import '../../../widgets/texts/my_text.dart';

// import '../challenge.dart';
import '../challenges/challenges_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _section3Key = GlobalKey();

  // Function to scroll to the section 3
  void scrollToSection3() {
    final RenderObject? renderObject =
        _section3Key.currentContext?.findRenderObject();
    if (renderObject is RenderBox) {
      final offsetY = renderObject.localToGlobal(Offset.zero).dy;
      _scrollController.animateTo(
        offsetY,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: MyColor.white1,
      body: Padding(
        padding: const EdgeInsets.only(top: 65, left: 20, right: 20),
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Column(
            children: [
              Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      MyText(
                        text: "Welcome Back Todi",
                        textStyle: MyStyle.black1_16_600,
                      ),
                      MyText(
                        text: "Todi Saputra",
                        textStyle: MyStyle.black1_30_800,
                      ),
                    ],
                  ),
                  Spacer(),
                  IconButton(
                    icon: Icon(
                      Icons.notifications_outlined,
                      size: height * 0.04,
                    ),
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: ((context) => NotificationPage())));
                    },
                  ),
                ],
              ),
              SizedBox(
                height: height * 0.03,
              ),
              Image.asset("images/google_add.png"),
              SizedBox(
                height: height * 0.03,
              ),
              Row(
                children: [
                  MyText(
                    text: "E Books",
                    textStyle: MyStyle.brown1_16_600,
                  ),
                  Spacer(),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: ((context) => BooksPage())));
                    },
                    child: MyText(
                      text: "See All",
                      textStyle: MyStyle.brown1_16_600,
                    ),
                  ),
                ],
              ),
              EBookCard(),
              SizedBox(
                height: height * 0.03,
              ),
              Row(
                children: [
                  MyText(
                    text: "Financial Coach",
                    textStyle: MyStyle.brown1_16_600,
                  ),
                  Spacer(),
                  MyText(
                    text: "See All",
                    textStyle: MyStyle.brown1_16_600,
                  ),
                ],
              ),
              SizedBox(
                height: height * 0.01,
              ),
              FinCoachCard(),
              SizedBox(
                height: height * 0.03,
              ),
              Row(
                children: [
                  MyText(
                    text: "My Appointments",
                    textStyle: MyStyle.brown1_16_600,
                  ),
                  Spacer(),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: ((context) => AppointmentPage())));
                    },
                    child: MyText(
                      text: "See All",
                      textStyle: MyStyle.brown1_16_600,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: height * 0.01,
              ),
              Container(key: _section3Key, child: MyAppointmentCard())
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
          shape: CircularNotchedRectangle(),
          elevation: 0,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              color: MyColor.blue1,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            height: height * 0.12,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  padding: EdgeInsets.all(6),
                  child: Icon(
                    Icons.home,
                    color: MyColor.white1,
                    size: height * 0.04,
                  ),
                  decoration: BoxDecoration(
                    color: MyColor.brown1,
                    borderRadius: BorderRadius.circular(100),
                  ),
                ),
                BottomIcon(
                    name: "Appointments",
                    icon: Icons.date_range_rounded,
                    onPressed: scrollToSection3),
                BottomIcon(
                  name: "Challenges",
                  icon: Icons.check_box_rounded,
                  onPressed: (() {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: ((context) => ChallengePage())));
                  }),
                ),
                BottomIcon(
                  name: "Reports",
                  icon: Icons.auto_graph_rounded,
                  onPressed: (() {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: ((context) => const ReportsPage())));
                  }),
                ),
                BottomIcon(
                  name: "Chats",
                  icon: Icons.chat_bubble_rounded,
                  onPressed: (() {
                    Navigator.push(context,
                        MaterialPageRoute(builder: ((context) => ChatPage())));
                  }),
                ),
                BottomIcon(
                  name: "More",
                  icon: Icons.more_horiz,
                  onPressed: (() {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: ((context) => const MorePage())));
                  }),
                )
              ],
            ),
          )),
    );
  }
}
