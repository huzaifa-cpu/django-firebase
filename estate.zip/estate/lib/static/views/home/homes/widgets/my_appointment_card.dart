import 'package:estate_mobile_app/static/views/home/appointments/view_appointment_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';

class MyAppointmentCard extends StatefulWidget {
  const MyAppointmentCard({super.key});

  @override
  State<MyAppointmentCard> createState() => _MyAppointmentCardState();
}

class _MyAppointmentCardState extends State<MyAppointmentCard> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Column(
      children: List.generate(
          7, // Number of times to display the custom card
          (index) => SizedBox(
                  // width: width,
                  child: GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: ((context) => ViewAppointmentPage())));
                },
                child: Card(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.01,
                      ),
                      Container(
                        width: width * 0.013,
                        color: MyColor.blue1,
                        height: height * 0.15,
                      ),
                      SizedBox(
                        width: width * 0.04,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  MyText(
                                      text: "Appointment Date",
                                      textStyle: MyStyle.grey1_14_500),
                                  SizedBox(
                                    height: height * 0.002,
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.watch_later_outlined,
                                        size: height * 0.022,
                                      ),
                                      SizedBox(
                                        width: width * 0.015,
                                      ),
                                      MyText(
                                          text: "Wed Jun 20 = 8:00 - 8:30 AM",
                                          textStyle: MyStyle.black1_15_200),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(
                                width: width * 0.09,
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.more_vert,
                                  size: height * 0.026,
                                ),
                                onPressed: () {},
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    height: height * 0.002,
                                  ),
                                  Card(
                                    elevation: 4.0,
                                    // Set the elevation for the card
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          100.0), // Set the border radius for the card
                                    ),
                                    child: ClipRRect(
                                      borderRadius:
                                          BorderRadius.circular(100.0),
                                      // Set the same border radius for the clip rectangle
                                      child: Image.asset(
                                        "images/coach-pic.png",
                                        // Replace with your own image URL
                                        fit: BoxFit.cover,
                                        height: height * 0.05,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                width: width * 0.02,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    height: height * 0.002,
                                  ),
                                  MyText(
                                      text: "Mark Johnson",
                                      textStyle: MyStyle.black1_11_500),
                                  SizedBox(
                                    height: height * 0.001,
                                  ),
                                  MyText(
                                      text: "Financial Advisor",
                                      textStyle: MyStyle.grey1_11_500),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ))),
    );
  }
}
