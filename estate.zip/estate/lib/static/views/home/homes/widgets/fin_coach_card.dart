import 'package:estate_mobile_app/static/views/home/appointments/appointment_details_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

import '../../../../utils/my_color.dart';
import '../../../../utils/my_style.dart';
import '../../../../widgets/texts/my_text.dart';

class FinCoachCard extends StatefulWidget {
  const FinCoachCard({super.key});

  @override
  State<FinCoachCard> createState() => _FinCoachCardState();
}

class _FinCoachCardState extends State<FinCoachCard> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return SizedBox(
      height: height * 0.14,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 5,
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: ((context) => AppointmentDetailsPage())));
            },
            child: SizedBox(
              width: width * 0.37,
              child: Card(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: width * 0.02,
                    ),
                    Container(
                      width: width * 0.01,
                      color: MyColor.blue1,
                      height: (height * 0.15) / 2,
                    ),
                    SizedBox(
                      width: width * 0.02,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: height * 0.01,
                        ),
                        Card(
                          elevation: 4.0, // Set the elevation for the card
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                                100.0), // Set the border radius for the card
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100.0),
                            // Set the same border radius for the clip rectangle
                            child: Image.asset(
                              "images/coach-pic.png",
                              // Replace with your own image URL
                              fit: BoxFit.cover,
                              height: height * 0.04,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: height * 0.01,
                        ),
                        MyText(
                            text: "Mark Johnson", textStyle: MyStyle.black1_11_500),
                        SizedBox(
                          height: height * 0.001,
                        ),
                        MyText(
                            text: "Financial Advisor",
                            textStyle: MyStyle.grey1_11_500),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
