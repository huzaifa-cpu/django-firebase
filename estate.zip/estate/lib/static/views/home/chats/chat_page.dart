// ignore_for_file: prefer_const_constructors

import 'package:estate_mobile_app/static/views/home/chats/message_page.dart';
import 'package:flutter/material.dart';

import '../../../../dynamic/dummy/chat_dummy_model.dart';
import '../../../utils/my_color.dart';
import '../../../utils/my_style.dart';
import '../../../widgets/texts/my_text.dart';

class ChatPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: MyColor.black1,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: MyText(
          text: 'Chats',
          textStyle: MyStyle.black1_25_800,
        ),
        elevation: 0,
      ),
      body: ListView.builder(
        itemCount: chats.length,
        itemBuilder: (BuildContext context, int index) {
          final chat = chats[index];

          if (chat == null || chat.time == null) {
            // Handle null chat or missing time property
            return SizedBox.shrink();
          }

          return Column(
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: ((context) => MessagePage())));
                },
                child: Container(
                  padding: EdgeInsets.all(13),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.asset(
                          chat.profilePic,
                        ),
                      ),
                      SizedBox(width: width * 0.05),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            MyText(
                              text: chat.name,
                              textStyle: MyStyle.black1_16_600,
                            ),
                            SizedBox(height: height * 0.006),
                            MyText(
                              text: chat.lastMessage,
                              textStyle: MyStyle.black1_15_200,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: width * 0.05),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          MyText(
                            text: chat.time,
                            textStyle: MyStyle.black1_12_000,
                          ),
                          SizedBox(height: height * 0.01),
                          Container(
                            padding: EdgeInsets.all(8.0),
                            decoration: BoxDecoration(
                              color: MyColor.brown1,
                              shape: BoxShape.circle,
                            ),
                            alignment: Alignment.center,
                            child: Center(
                              child: MyText(
                                text: chat.unreadMessages.toString(),
                                textStyle: MyStyle.white1_12_700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Divider(),
            ],
          );
        },
      ),
    );
  }
}
