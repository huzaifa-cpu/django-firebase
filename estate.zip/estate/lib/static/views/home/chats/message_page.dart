// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_key_in_widget_constructors
// import 'dart:js';

import 'package:estate_mobile_app/dynamic/dummy/message_dummy_model.dart';
import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:flutter/material.dart';

import '../../../widgets/texts/my_text.dart';

class MessagePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Column(
        children: [
          Container(
            height: height * 0.2,
            decoration: BoxDecoration(
              color: MyColor.blue1,
              borderRadius: BorderRadius.vertical(
                bottom: Radius.circular(30),
              ),
            ),
            child: Column(
              children: [
                SizedBox(height: height * 0.09),
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: MyColor.white1),
                      onPressed: () {
                        Navigator.pop(
                            context); // Navigate back when back arrow is pressed
                      },
                    ),
                    SizedBox(width: width * 0.05),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.asset(
                        'images/profile_1.png',
                      ),
                    ),
                    SizedBox(width: width * 0.05),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'John Doe', // User name
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: MyColor.white1),
                        ),
                        MyText(
                          text: 'Online', // Online status or typing status
                          textStyle:
                              TextStyle(fontSize: 16, color: MyColor.white1),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: MyColor.white1,
              child: ListView.builder(
                reverse: true,
                padding: EdgeInsets.all(10),
                itemCount: messages.length,
                itemBuilder: (context, index) {
                  return chatMessageItem(messages[index], context);
                },
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Type your message...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.transparent),
                        borderRadius: BorderRadius.circular(5),
                      ),
                      contentPadding: EdgeInsets.symmetric(
                        vertical: 10,
                        horizontal: 20,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Container(
                  decoration: BoxDecoration(
                    color: MyColor.blue1,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: IconButton(
                    icon: Icon(
                      Icons.send,
                      color: MyColor.white1,
                    ),
                    onPressed: () {
                      // Send message functionality
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget chatMessageItem(MessageDummyModel message, BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Container(
      margin: EdgeInsets.symmetric(vertical: 15),
      child: Container(
        alignment:
            message.isSender ? Alignment.centerRight : Alignment.centerLeft,
        child: message.isSender
            ? senderLayout(message, context)
            : receiverLayout(message, context),
      ),
    );
  }

  Widget senderLayout(MessageDummyModel message, BuildContext context) {
    // HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Column(
              children: [
                Icon(
                  Icons.done_all,
                  color: MyColor.green1,
                ),
                Text(
                  message.time,
                ),
              ],
            ),
          ),
          Spacer(),
          Expanded(
            flex: 3,
            child: Container(
              padding: EdgeInsets.all(12),
              margin: EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: MyColor.grey2,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: height * 0.003),
                  Text(
                    message.message,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget receiverLayout(MessageDummyModel message, BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          Expanded(
            flex: 4,
            child: Container(
              padding: EdgeInsets.all(12),
              margin: EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: MyColor.grey2,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: height * 0.003),
                  Text(
                    message.message,
                  ),
                ],
              ),
            ),
          ),
          Spacer(),
          Expanded(
            flex: 1,
            child: Column(
              children: [
                // Icon(Icons.done),
                // Icon(Icons.done_all),
                Text(
                  message.time,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
