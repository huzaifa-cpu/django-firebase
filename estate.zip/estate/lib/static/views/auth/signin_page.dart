// ignore_for_file: prefer_const_constructors

import 'package:estate_mobile_app/static/utils/my_color.dart';
import 'package:estate_mobile_app/static/views/auth/forget_password_page.dart';
import 'package:estate_mobile_app/static/views/auth/signup_page.dart';
import 'package:estate_mobile_app/static/views/home/homes/home_page.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_button.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_small_button.dart';
import 'package:estate_mobile_app/static/widgets/textfields/my_textfield.dart';
import 'package:estate_mobile_app/static/widgets/textfields/my_underline_textfield.dart';
import 'package:estate_mobile_app/static/widgets/texts/my_text.dart';
// import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../widgets/textfields/outlined_textfield.dart';

class SigninPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  height: height * 0.28,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: const AssetImage('images/intro_image.png'),
                      fit: BoxFit.cover,
                      colorFilter: ColorFilter.mode(
                          Colors.black.withOpacity(0.7), BlendMode.darken),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 60.0),
                  child: Center(
                    child: Image.asset(
                      'images/estate_logo_white.png',
                      height: height * 0.15,
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: EdgeInsets.all(18.0),
              child: Column(
                // mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MyText(
                    text: "LET'S SIGN IN",
                    textStyle: TextStyle(
                        fontSize: 24.0, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: height * 0.01),
                  MyText(
                    text:
                        "Enter your email and password and start exploring ESTATE",
                    textStyle: TextStyle(
                      fontSize: 16.0,
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: height * 0.02),
                  MyTextField(hintText: "Enter your email address"),
                  SizedBox(height: height * 0.01),
                  MyUnderlineTextfield(hintText: "Enter password",),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: ((context) => ForgetPasswordPage())));
                      },
                      child: MyText(
                        text: 'Forgot Password?',
                        textStyle: TextStyle(
                            color: MyColor.blue1,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  SizedBox(height: height * 0.01),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          child: CouponTextfield(),
                        ),
                      ),
                      SizedBox(width: 10.0),
                      MySmallButton(text:"Apply", onPressed: (){},),
                    ],
                  ),
                  SizedBox(height: height * 0.03),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MyButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: ((context) => HomePage())));
                        },
                        text: "SIGNIN",
                      )
                    ],
                  ),
                  SizedBox(height: 10.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MyText(
                        text: "NEW USER?",
                        textStyle: TextStyle(
                          color: MyColor.blue1,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: ((context) =>
                                      SignupPage())));
                        },
                        child: MyText(
                          text: "JOIN US",
                          textStyle: TextStyle(
                              color: MyColor.blue1,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: height * 0.01),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Material(
                        elevation: 4,
                        shape: CircleBorder(),
                        child: CircleAvatar(
                          backgroundColor: MyColor.white1,
                          child: Image.asset(
                            'images/playstore.png',
                            height: 25,
                            // width: 25,
                          ),
                        ),
                      ),
                      SizedBox(width: 10.0),
                      Material(
                        elevation: 4,
                        shape: CircleBorder(),
                        child: CircleAvatar(
                          backgroundColor: MyColor.white1,
                          child: Image.asset(
                            'images/apple store.png',
                            height: 30,
                            // width: 30,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
