// ignore_for_file: prefer_const_constructors, use_key_in_widget_constructors, sized_box_for_whitespace

import 'package:estate_mobile_app/static/views/home/homes/home_page.dart';
import 'package:estate_mobile_app/static/widgets/textfields/my_textfield.dart';
import 'package:estate_mobile_app/static/widgets/textfields/my_underline_textfield.dart';
import 'package:flutter/material.dart';

import '../../utils/my_color.dart';
import '../../widgets/buttons/my_button.dart';
import '../../widgets/texts/my_text.dart';

class SignupPage extends StatefulWidget {
  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        child: SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                children: [
                  Container(
                    height: MediaQuery.of(context).size.height / 3,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: const AssetImage('images/intro_image.png'),
                        fit: BoxFit.cover,
                        colorFilter: ColorFilter.mode(
                            Colors.black.withOpacity(0.7), BlendMode.darken),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 60.0),
                    child: Center(
                      child: Image.asset(
                        'images/estate_logo_white.png',
                        height: height * 0.15,
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  // mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    MyText(
                      text: "LET'S SIGN UP",
                      textStyle: TextStyle(
                          fontSize: 24.0, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: height * 0.02),
                    MyText(
                      text:
                          "Enter your email and password with other details to explore ESTATE",
                      textStyle: TextStyle(
                        fontSize: 16.0,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: height * 0.02),
                    MyTextField(hintText: "Enter username"),
                    SizedBox(height: height * 0.01),
                    MyTextField(hintText: "Enter full name"),
                    SizedBox(height: height * 0.01),
                    MyTextField(hintText: "Enter your email address"),
                    SizedBox(height: height * 0.01),
                    MyUnderlineTextfield(hintText: "Enter password"),
                    SizedBox(height: height * 0.01),
                    MyTextField(hintText: "Confirm password"),
                    SizedBox(height: height * 0.02),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        MyButton(
                          onPressed: (() {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: ((context) => HomePage())));
                          }),
                          text: "SIGNUP",
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
