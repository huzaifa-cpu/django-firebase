// import 'dart:ui';

// ignore_for_file: prefer_const_constructors

// import 'package:estate_mobile_app/static/utils/colors.dart';
import 'package:estate_mobile_app/static/views/auth/signin_page.dart';
import 'package:estate_mobile_app/static/views/auth/signup_page.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_border_button.dart';
import 'package:estate_mobile_app/static/widgets/buttons/my_button.dart';
import 'package:flutter/material.dart';

import '../../utils/my_color.dart';

class LoginPage extends StatefulWidget {
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    //HEIGHT-WIDTH
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  width: double.infinity,
                  height: height * 0.50,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('images/intro_image.png'),
                      fit: BoxFit.fitHeight,
                      colorFilter: ColorFilter.mode(
                          Colors.black.withOpacity(0.7), BlendMode.darken),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(35.0),
                  child: Image.asset(
                    'images/estate_logo_white.png',
                    height: height * 0.47,
                  ),
                ),
              ],
            ),
            SizedBox(height: height * 0.04),
            Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              MyButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: ((context) => SigninPage())));
                },
                text: "LOGIN",
              ),
              SizedBox(height: 15),
              MyBorderButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: ((context) => SignupPage())));
                  
                },
              ),
              SizedBox(height: 70),
              Text(
                "Need Help ?",
                style: TextStyle(color: MyColor.blue1, fontSize: 18),
              )
            ]),
          ],
        ),
      ),
    );
  }
}
